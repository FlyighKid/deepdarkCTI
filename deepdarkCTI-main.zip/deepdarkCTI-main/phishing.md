|Name|Status|Description|
| ------ | ------ | ------ |
|[CheckPhish](https://checkphish.ai)| ONLINE | |
|[EasyDmark](https://easydmarc.com/tools/phishing-url)| ONLINE | |
|[IsitPhishing](https://isitphishing.org)| ONLINE | |
|[OpenPhish](https://openphish.com)| ONLINE | |
|[PhishBank](https://phishbank.org)| OFFLINE | |
|[Phishing Kit](https://github.com/0xDanielLopez/phishing_kits)| ONLINE | |
|[Phishing.Database](https://github.com/mitchellkrogza/Phishing.Database)| ONLINE | |
|[PhishingArmy](https://phishing.army)| ONLINE | |
|[PhishingCheck](https://phishcheck.me)| ONLINE | |
|[PhishingInitiative](https://phishing-initiative.fr/contrib)| ONLINE | |
|[PhishHunt](https://phishunt.io)| ONLINE | |
|[PhishStats](https://phishstats.info)| ONLINE | |
|[PhishTank](https://www.phishtank.com)| ONLINE | |
|[StopForumSpam](https://www.stopforumspam.com)| ONLINE | |
|[ThreatCOp](https://threatcop.com/phishing-url-checker)| ONLINE | |
|[urlscan.io](https://urlscan.io)| ONLINE | |
|[urlDNA.io](https://urldna.io/)| ONLINE | |
|[StalkPhish.io](https://www.stalkphish.io/)| ONLINE | |
