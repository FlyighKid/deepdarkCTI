|Name|Status|Description|
| ------ | ------ | ------ |
|[ETERNITY](http://malwarewrn7fvd7zq243d74dxs3ca4wh5kw6i2opkzeusuoajtd2j5yd.onion) | OFFLINE | |
|[ETERNITY](http://rlcjba7wduej3xcstcjo577eqgjsjvcjfsw4i23fqvf2y27ylylhmhad.onion) | ONLINE | |
|[ETERNITY (mirror)](http://eternityms33k74r7iuuxfda4sqsiei3o3lbtr5cpalf6f4skszpruad.onion) | ONLINE | |
|[RACCOON](https://raccoon.biz) | ONLINE | |
|[RANION (Tor v2)](http://ranionjgot5cud3p.onion)| OFFLINE | |
|[RANION (Tor v3)](http://ranionv3j2o7wrn3um6de33eccbchhg32mkgnnoi72enkpp7jc25h3ad.onion)| ONLINE | |
|[RANION (Tor v3)](http://yfcztpdrhan2bjnensc6xd5zibbcbqrmccmkrrulfdgivhlcaomszwqd.onion)| ONLINE | |
|[RANION](http://dozrkm62j2uysnqg57q35cangl2lpgdirhxbcc2yzpcgvfyowy7syxqd.onion)| ONLINE | |
|[RANION](http://ni3kiymt4jc32baea356vhwurba44jabfklitpoqbrtgrhr5skyrixyd.onion)| ONLINE | |
|[STEALER VIRUS](https://t.me/erna_channel)| ONLINE | |
