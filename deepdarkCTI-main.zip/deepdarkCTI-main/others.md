|Name|Status|Description|
| ------ | ------ | ------ |
|[185.149.41.46](http://185.149.41.46/)| ONLINE | |
|[ALL WORLD CARDS](http://awcardsqtyy2nzjz4bqwbccvv6xr4bdcwcgfyewd7gsx5mhh63c2lsad.onion)| OFFLINE | |
|[ANONHOSTING](https://anonhosting.io/list.php)| ONLINE | |
|[ANONLEAKS.LIVE](https://anonymousleaks.live)| ONLINE | |
|[ANONLEAKS.XYZ](https://anonymousleaks.xyz)| OFFLINE | |
|[BL4CKT0R](http://bl4cktorpms2gybrcyt52aakcxt6yn37byb65uama5cimhifcscnqkid.onion)| ONLINE | |
|[BREACHED DB](http://breachdbsztfykg2fdaq2gnqnxfsbj5d35byz3yzj73hazydk4vq72qd.onion)| ONLINE | |
|[BREACHED WIKI](https://breached.wiki)| ONLINE | |
|[BLACKVAULT](https://blackvault.cc)| ONLINE| |
|[CVE Trends - crowdsourced CVE intel](https://cvetrends.com/)| OFFLINE | Offline due changes in Twitter API |
|[DARK LEAK MARKET](http://54rdhzjzc4ids4u4wata4zr4ywfon5wpz2ml4q3avelgadpvmdal2vqd.onion)| OFFLINE | |
|[DARK ARMY](http://darkarmy5dhdw5jbml2mitgpaorzdiubxxiq5tdzsqidz55kygsrz7id.onion)| ONLINE | |
|[DARK FAIL](https://dark.fail)| ONLINE | |
|[DARKFEED LIVE RANSOMWARE MONITOR](https://darkfeed.io/indexransomware)| OFFLINE | |
|[DARKFEED RANSOMWIKI](https://darkfeed.io/ransomwiki)| OFFLINE | |
|[DARKTOR](http://darktorhvabc652txfc575oendhykqcllb7bh7jhhsjduocdlyzdbmqd.onion)| OFFLINE | |
|[DDOSECRETS](https://ddosecrets.com)| ONLINE | |
|[DEEP DATABASE LEAK MARKET](http://a7fgazjfsn5kwk2psase4oepogihgvb3bm4enomnyfg52dwghdymeyqd.onion)| OFFLINE | |
|[DOUBLE EXTORTION PLATFORM](https://doubleextortion.com/#/land)| ONLINE ||
|[DOXBIN](https://doxbin.org)| ONLINE | |
|[HAPPY BLOG](http://dnpscnbaix6nkwvystl3yxglz7nteicqrou3t75tpcc5532cztc46qyd.onion)| OFFLINE | |
|[HAYSTACK SEARCH ENGINE](http://haystakvxad7wbk5.onion)| OFFLINE | |
|[HIDDEN LINKS](http://wclekwrf2aclunlmuikf2bopusjfv66jlhwtgbiycy5nw524r6ngioid.onion)| ONLINE | |
|[I2P SEARCH ENGINE](http://i2poulge3qyo33q4uazlda367okpkczn4rno2vjfetawoghciae6ygad.onion)| ONLINE | |
|[Zero Trust LTD leak search](https://search.0t.rocks/)| ONLINE | For JSON API Access contact miyako@miyako.rocks (rebrand of search.illicit.services) |
|[Lapsus$ Matrix Chat](https://matrix.to/#/#lapsus:matrix.org)| ONLINE | |
|[LeakTheAnalyst](http://leaktheanalyst.fireeye62c3da3fnosymmmcqcty7rl7cjucpbkzaz275a4qs5fgkzhad.onion)| OFFLINE | | 
|[LINK BASE](https://link-base.org)| ONLINE | Various forums links |
|[LYZEM](https://lyzem.com)| ONLINE | Telegram search engine |
|[HOMELAND JUSTICE](http://homelandjustice.ru)| ONLINE | HomeLand Justice |
|[OPHELIAS SECRETS](http://5uijdqvyqciohojtx62mdtqqyf2ezfd2fcfref6uryx26wspuliwxkyd.onion)| OFFLINE | |
|[PHOBOS SEARCH ENGINE](http://phobosxilamwcg75xt22id7aywkzol6q6rfl2flipcqoc4e4ahima5id.onion)| ONLINE | |
|[PROGRAMMABLE SEARCH ENGINE](https://cse.google.com/cse?&cx=006368593537057042503:efxu7xprihg#gsc.tab=0)| ONLINE | |
|[PWNDB](http://pwndb2am4tzkvold.onion)| OFFLINE | |
|[QUANTUM BLOG](http://quantum445bh3gzuyilxdzs5xdepf3b7lkcupswvkryf3n7hgzpxebid.onion)| ONLINE | |
|[RAASNET](http://hplqdv5fo3vw3fjyamyer7yuc7xtvtop2j3fipc7psf3pxvhoqjoqkid.onion)| ONLINE | |
|[RANSOMWARE PAYMENTS TRACKER](https://ransomwhe.re)| ONLINE | |
|[RANSOMWARE VICTIMS TRACKER](https://ransom.wiki)| ONLINE | |
|[SAUDI ARAMCO LEAK](http://662m7dfcpfsmeetqucdekz3rn4a6dxsxbdjwd6iz3rwnogjsj7i3hxad.onion)| OFFLINE | |
|[StrangerealIntel](https://github.com/StrangerealIntel)| ONLINE |GitHub Repo|
|[THE DIGEST CRYPTO-RANSOMWARE](https://id-ransomware.blogspot.com)| ONLINE | |
|[TWEETFEED](https://github.com/0xDanielLopez/TweetFeed)| ONLINE | GitHub Repo|
|[TOR INDEX TAXI](http://tortaxi7axhn2fv4j475a6blv7vwjtpieokolfnojwvkhsnj7sgctkqd.onion)| ONLINE | |
|[UKRAINE LEAK](http://gcbejm2rcjftouqbxuhimj5oroouqcuxb2my4raxqa7efkz5bd5464id.onion)| ONLINE | |
|[VISITOR SEARCH ENGINE](http://visitorfi5kl7q7i.onion)| OFFLINE | |
|[VXVAULT](http://vxvault.net/ViriList.php)| ONLINE | |
|[VX-Underground](https://www.vx-underground.org/#E:/root)| ONLINE | |
|[TELEGRAM FRAUDSTER GLOSSARY](https://docs.google.com/spreadsheets/d/1-ICFqnnm0DryaVfCdp7NwleGG03pJorT63bEMPBmji8/htmlview)| ONLINE | |
|[OFFSHORE.CAT - offshore hosting list](https://offshore.cat) | ONLINE | |
|[Check-The-Sum - Malicious IP and domains](https://check-the-sum.fr) | ONLINE | |
|[WITHA.NAME](http://withanamemwesdvodfhthjq25a5a3uas24cpgoa7qm6gchcerzpis6qd.onion) | ONLINE | |
