|Link| Description |
| ------ | ------ |
|https://github.com/0xDanielLopez/| TweetFeed |
|https://twitter.com/altoufanteam | Al Toufan Team |
|https://twitter.com/Arkbird_SOLG| Malware hunter & analyst |
|https://twitter.com/crep1x | Threat Analyst |
|https://twitter.com/Cryptolaemus1 | Threat Hunting group |
|https://twitter.com/Cyberknow20 | Situational Awareness |
|https://twitter.com/ecarlesi | Phishing IOC |
|https://twitter.com/EmotetB | Emotet OSINT | 
|https://twitter.com/executemalware | Malware hunter & analyst |
|https://twitter.com/htmalgae | Security Researcher & Dark Net Pest |
|https://twitter.com/JAMESWT_MHT | Malware Samples |
|https://twitter.com/mojoesec | Cobalt Strike IOC |
|https://twitter.com/PhishStats | Realtime phishing database & statistics |
|https://twitter.com/powershellcode | Malware hunter & analyst |
|https://twitter.com/pr0xylife | Emotet OSINT |
|https://twitter.com/TMRansomMonitor | ThreatMon Ransomware Monitoring |
|https://twitter.com/RdpSnitch | A bot who snitches on RDP Scanners, sharing IOC |
|https://twitter.com/reecdeep | Malware Analyst | 
|https://twitter.com/shadowchasing1 | APT IOC |
|https://twitter.com/thedfirreport | APT IOC |
|https://twitter.com/vuldb | APT actors & IOC |
|https://twitter.com/vxunderground | malware samples |
|https://tweetfeed.live | Tweet Feed |
|https://x.com/KeymousTeam| keymous+ DDoS |
