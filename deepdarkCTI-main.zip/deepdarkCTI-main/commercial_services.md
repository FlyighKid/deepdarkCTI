|Name|Description|Link|
| ------ | ------ | ------ |
|ECRIME|Platform that index ransomware and data leak sites|https://ecrime.ch|
|HUDSON ROCK|Cybercrime Intelligence Tools|https://www.hudsonrock.com/threat-intelligence-cybercrime-tools|
|KEYSCO|Lookups for email, username & others|https://x.keysco.re|
|LEAK LOOKUP|Lookups for email|https://leak-lookup.com/breaches|
|VENARI INTEL FEED|Intel Feed|https://t.me/venarix|
