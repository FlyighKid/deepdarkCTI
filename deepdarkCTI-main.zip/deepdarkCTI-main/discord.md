|Name|Status|Description|
| ------ | ------ | ------ |
|[_db [breach]](https://discord.gg/j3HmDmhh)| Expired | |
|[OpticalMarket](https://discord.gg/kUyhdgvM)| Expired | |
|[Eros Market](https://discord.gg/YZmJNjcG)| Expired | |
|[LolzTeam](https://discord.com/invite/lzt)| ONLINE| |
|[VXUnderground](https://discord.com/invite/3mxXqnD78a)| Expired | |
|[AgainstTheWest](https://discord.com/invite/wCRH46NgEF)| Expired | |
