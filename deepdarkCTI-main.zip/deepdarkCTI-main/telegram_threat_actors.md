|Telegram|Status|Threat Actor Name|Type of attacks|
| ------ | ------ | ------ | ------ |
|https://t.me/+6OJjr1dDbQw1NDli|EXPIRED| RED HACKERS ALLIANCE ||
|https://t.me/+7VXL5Gy9NUc1YzFl|VALID| Darknet chat||
|https://t.me/+8UWtFO9H_9dhODVk|EXPIRED| 0x_dump alternative channel||
|https://t.me/+9ETFYLy5Tc1lNzBh|VALID|Ares private channel||
|https://t.me/+9P5FQ85afTc4NGNl|VALID| Goblin's Database ||
|https://t.me/aaron_bushneII|ONLINE|Aaron Bushnell hackers||
|https://t.me/AC3HCYBER|OFFLINE|ACEH||
|https://t.me/AccountSquadChat|ONLINE|Illicit Service Group||
|https://t.me/ACCOUNTSQUAD|OFFLINE|Illicit Service Channel||
|https://t.me/aidlock/|ONLINE| AiDLocker group channel||
|https://t.me/Allhak_mv|ONLINE| Data Leaks|
|https://t.me/altenens|ONLINE||
|https://t.me/anarchy_squad|OFFLINE| [ Cyber.Anarchy.Squad ]||
|https://t.me/anon_by|ONLINE| Anonymous Russia channel||
|https://t.me/anoncambodia|OFFLINE| ||
|https://t.me/AnonCollective|OFFLINE|Anonymous Collective||
|https://t.me/AnonimLegion|OFFLINE|KaliHunt/Russia||
|https://t.me/ANONM0S_RU|OFFLINE|Anonymous Russia||
|https://t.me/anon_sec_Official|ONLINE|Anon Sec|Data Leak|
|https://t.me/AnonymousEgypt|OFFLINE|Anonymous Egypt|Data Leak|
|https://t.me/Anonymous_revengers|ONLINE|UnderWorld Hacking Group||
|https://t.me/anonymous_south_africa|ONLINE|Anonymous South Africa|Data Leak|
|https://t.me/AnonymousSudan|OFFLINE|Anonymous Sudan||
|https://t.me/AntiPlumbers|ONLINE||
|https://t.me/anzu_team|ONLINE|Anzu Team||
|https://t.me/APIddosMirai|ONLINE| Killnet API DDoS Mirai |DDoS|
|https://t.me/APTANALYSIS|OFFLINE|Exploits||
|https://t.me/APTIRAN|ONLINE|APT Iran||
|https://t.me/Arab_Hackers_Union|OFFLINE|Arab Hackers Union||
|https://t.me/aresmainchannel|OFFLINE| Data Leaks ||
|https://t.me/arvinclub1|OFFLINE|Arvin||
|https://t.me/Arvin_club2|OFFLINE| Data Leaks ||
|https://t.me/arvin_club|OFFLINE||
|https://t.me/asdcloud|OFFLINE|Combo List||
|https://t.me/atlantiscyberarmy|ONLINE|Atlantis - CyberArmy - A.I.G||
|https://t.me/atw2022|ONLINE| Against The West ||
|https://t.me/AutoLookup|ONLINE|AutoLookup||
|https://t.me/awsleaks|OFFLINE|AWS Leaks||
|https://t.me/azzasec|OFFLINE|AzzaSec||
|https://t.me/baphchat|ONLINE|The Jacuzzi||
|https://t.me/base_brutesu|ONLINE| Combo List|
|https://t.me/baseleak|ONLINE| Data Leaks ||
|https://t.me/+Bat9QqJcSuE0MTg1|VALID| AresLoader ||
|https://t.me/bazubd|OFFLINE| Data Leaks||
|https://t.me/BAZU_BD|OFFLINE| Data Leaks||
|https://t.me/BEARITARMY|OFFLINE| BEAR IT ARMY ||
|https://t.me/BEARITARMY|ONLINE|BearITArmy||
|https://t.me/BEARSPAW_RESERVS|ONLINE|BearSpaw (now they are Digital Revolt)||
|https://t.me/best_cracking_soft|ONLINE|Illicit Service||
|https://t.me/bidencashfreecvv|ONLINE|BidenCash CVV [ANTIPUBLIC]||
|https://t.me/bl00dy_Ransomware_Gang|ONLINE| Bl00dy ransomware gang ||
|https://t.me/Bl4ck_Room|ONLINE| Checkers, Hacking Tools ||
|https://t.me/blackforumsarchive|ONLINE|BlacksForums archive||
|https://t.me/blackforumsbf|OFFLINE|Blackforum||
|https://t.me/blackshadowhackers|OFFLINE| Blackshadow Hackers ||
|https://t.me/blackvaultcc|ONLINE|Blackvault||
|https://t.me/Blank_Link|OFFLINE||
|https://t.me/BLOODNET_RUS|ONLINE|Bloodnet|
|https://t.me/blueteamzone|OFFLINE||
|https://t.me/boosty66brvte|OFFLINE| Data Leaks ||
|https://t.me/breachchat|OFFLINE|Jacuzzi 5.0||
|https://t.me/breachdetector|ONLINE||
|https://t.me/breachdetector|ONLINE| Data Leak Monitor||
|https://t.me/breachedannouncements|OFFLINE|Breach Forum Announcements||
|https://t.me/BreachedData|OFFLINE| Data Leaks ||
|https://t.me/BreachedDB|OFFLINE| Data Leaks ||
|https://t.me/BreachedDiscussion|OFFLINE| Data Leaks ||
|https://t.me/bugatti_cloud|OFFLINE| Bugatti Cloud Redline Stealer|Infostealer|
|https://t.me/Bust3d|ONLINE| волчья свалка||
|https://t.me/c0xCee|OFFLINE| Data Leaks ||
|https://t.me/c/1228309110/7662|PRIVATE| Ddosia project chat|DDoS|
|https://t.me/canyoupwnme|ONLINE| News ||
|https://t.me/cas_files|ONLINE| Data Leaks ||
|https://t.me/cbanke_market|OFFLINE| Data Leaks ||
|https://t.me/cbanke|ONLINE| Data Leaks||
|https://t.me/CHO1CHO1|ONLINE|CH01 group||
|https://t.me/cityofleaker|OFFLINE| Leaks ||
|https://t.me/civiliandarkcode404|ONLINE|Civilan dark code||
|https://t.me/clean_tools_net|OFFLINE|Clean Tools||
|https://t.me/cloudata_free_databases|OFFLINE|Free Data Breaches Provider||
|https://t.me/club1337|OFFLINE||
|https://t.me/combo2021|OFFLINE| Combo List||
|https://t.me/Combolistfresh|ONLINE| Combo List||
|https://t.me/combo_listt|OFFLINE| Combo List ||
|https://t.me/combo_offensive|ONLINE| Combo List ||
|https://t.me/combosgrupoplex|ONLINE| Combo List ||
|https://t.me/Comments_RHA_Russia_chat|ONLINE| Red Hackers Alliance Chat Group ||
|https://t.me/config_combos|OFFLINE| Configs, Combos ||
|https://t.me/Configsandcombos|OFFLINE| Configs, Combos ||
|https://t.me/ConfigsServices|ONLINE| Configs, Combos ||
|https://t.me/CoupTeam|ONLINE|Coup Team||
|https://t.me/cpartisans|ONLINE| Кибер-Партизаны (Cyber Partisans) ||
|https://t.me/crackcodes|ONLINE| Data Leaks ||
|https://t.me/CrackerConfigs|OFFLINE| Configs, Combos ||
|https://t.me/Crackers_Club|OFFLINE| Configs, Combos ||
|https://t.me/Craxpro_Channel|OFFLINE|Cracking, spamming, carding||
|https://t.me/crewcomboteam|ONLINE| Combo List||
|https://t.me/crewcomboteams|OFFLINE| Crew Combo Teams||
|https://t.me/cristallineforum|ONLINE|Cristalline Forum||
|https://t.me/CryptoGinzo|OFFLINE| Crypt_0x00 ||
|https://t.me/ctifeeds|ONLINE|Cyber Threat Intelligence Feeds||
|https://t.me/cveNotify|ONLINE| CVE Feed||
|https://t.me/cyb3rtr0nian|ONLINE||
|https://t.me/cybdetective|ONLINE| News & Info Sharing ||
|https://t.me/cyberactiveXXII|ONLINE| CA XXII Hacktivist Gang ||
|https://t.me/cyber_anarchy_squad|ONLINE| [ Cyber.Anarchy.Squad ]||
|https://t.me/CyberArmyofRussia_Reborn|OFFLINE|Sandworm||
|https://t.me/CyberAv3ngers|ONLINE|Cyber Av3ngers||
|https://t.me/CyberAveng3rs|OFFLINE|Cyber Aveng3rs||
|https://t.me/CyberCatChat|OFFLINE|Cyber Cat chat||
|https://t.me/CyberCatHack|ONLINE|Cyber Cat channel||
|https://t.me/cybercourt_io|ONLINE|Cyber Court||
|https://t.me/cybercourt_io|ONLINE|CyberCourt Group (pro Palestine) - https://cybercourt.io|Data Leak|
|https://t.me/CyberDragonRussia|OFFLINE|Cyber Dragon Russia||
|https://t.me/CyberToufanBackup|OFFLINE|CyberToufan|Data Leaks||
|https://t.me/D3atr0y3d|OFFLINE| Data Leaks||
|https://t.me/D3v1LZoNe|ONLINE| Devilzone 1 - configs, combos ||
|https://t.me/D7BBUK|OFFLINE|D7BBUK||
|https://t.me/DailyCombos1|OFFLINE| Combo List||
|https://t.me/DailyCombos|OFFLINE| Combo List||
|https://t.me/dailydarkweb|ONLINE| Data Leaks ||
|https://t.me/DarkBitChannel|ONLINE|Darkbit Channel||
|https://t.me/darkclubpw|OFFLINE| Dark Club Market ||
|https://t.me/DarkfeedNews|ONLINE| News ||
|https://t.me/DarkForumsME|OFFLINE|Dark Forums|Cyber crime forum|
|https://t.me/DarkForums|ONLINE|Dark Forums||
|https://t.me/darknet_br|OFFLINE| ||
|https://t.me/DarknetNewsEng|OFFLINE| Darknet News(English Version)||
|https://t.me/DarkSeek_rus|OFFLINE|DarkSeek Hacking Group||
|https://t.me/DarkStormTeamd|OFFLINE|Dark Storm Team||
|https://t.me/DarkStormTeams|OFFLINE|Dark Storm Team||
|https://t.me/darkvaultransom|OFFLINE|Dark Vault ransom|Ransomware|
|https://t.me/darkwebdarknetmarketplace|OFFLINE|Illicit Service||
|https://t.me/darxe_base|OFFLINE| Data Leaks ||
|https://t.me/data1eaks|OFFLINE| ||
|https://t.me/Database_breached|OFFLINE| Data Leaks ||
|https://t.me/databasemarkett|ONLINE|Database Market||
|https://t.me/databreach|ONLINE| ||
|https://t.me/datacloudspace|OFFLINE| Combo List||
|https://t.me/dataflows|ONLINE| Data Leaks ||
|https://t.me/dataleakbreach|OFFLINE| Data Leaks||
|https://t.me/DataLeakHome|ONLINE| Data Leaks ||
|https://t.me/dataleaksua|OFFLINE| Data Dumps; ESP Russian ||
|https://t.me/+_d-aW--RLXszYmU0|VALID|Openbullet Config Service||
|https://t.me/dbforall|OFFLINE| ||
|https://t.me/DBleak|ONLINE| Data Leaks ||
|https://t.me/DB_MARKEETS|OFFLINE| Data Leaks ||
|https://t.me/db_rf_rb|OFFLINE| Data Leaks ||
|https://t.me/ddossatmak|ONLINE| DDoS Services |DDoS|
|https://t.me/ddos_separ|ONLINE| DDoS Services |DDoS|
|https://t.me/ddostm1|ONLINE| BlackObServers Channel (ddos team) |DDoS|
|https://t.me/Digital_Revolt_hack|ONLINE|Digital Revolt||
|https://t.me/divergent_group|OFFLINE| Divergent Group||
|https://t.me/+DLb_tfrPeE4wNDM8|EXPIRED|Biskooit Pedar||
|https://t.me/dontleakmydata|OFFLINE|DontLeakMyData||
|https://t.me/dragonforceio|ONLINE|DragonForce Malaysia||
|https://t.me/DumpedOfficial|ONLINE|Dumped forum||
|https://t.me/dumpforums|OFFLINE| Dump Forums ||
|https://t.me/DWI_OFFICIAL|OFFLINE| ||
|https://t.me/+E0eng43CkZowMTdl|EXPIRED|BF Repo V3 Files||
|https://t.me/eaglecyberwashere|ONLINE|Eaglecyber||
|https://t.me/ehdanstock|ONLINE| Selling Accounts ||
|https://t.me/eightbase|ONLINE| 8BASE ||
|https://t.me/emailistsdatabase|ONLINE|Combo List||
|https://t.me/+eOtgrt4gB68wM2Qy|EXPIRED| Atlantis Cyber Army A.I.G. - backup||
|https://t.me/+eRl4m-fdPl8yZTUx|EXPIRED|Snatch channel||
|https://t.me/EternityMalwareTeam|ONLINE| Eternity Malware ||
|https://t.me/EVILEAKSU|OFFLINE| UNLISTEDLEAKS||
|https://t.me/exploit_db_com|OFFLINE| Exploits ||
|https://t.me/ExploitService|ONLINE|Exploit Service||
|https://t.me/exposedannouncements|OFFLINE|Exposed Forum||
|https://t.me/FiveFamilies|OFFLINE|FiveFamilies||
|https://t.me/flannels|ONLINE| Market ||
|https://t.me/+fR-06lKTQ_VmODA0|EXPIRED| Data Leaks ||
|https://t.me/fr33d4t4|OFFLINE| Fr33 d4t4 - stolen redline from other channels||
|https://t.me/FR3DENSOFSECURITY_2023|OFFLINE| ||
|https://t.me/freeDEFAULFcloud|OFFLINE| Defaulf Cloud (Redline Stealer)|Infostealer|
|https://t.me/freedomf0x|ONLINE| ||
|https://t.me/freepalestine_PPHM|OFFLINE|Pro-Palestine Hackers Movement||
|https://t.me/freshtoolsnet|ONLINE|Freshtools Market||
|https://t.me/friendastrokal|ONLINE| Combo List||
|https://t.me/fuckeddb|OFFLINE| ||
|https://t.me/+FuLjnRtP3BhiZDNl|VALID| Goblin's Hub (private) | |
|https://t.me/garudasec4|OFFLINE|Garuda Security||
|https://t.me/GhostSecc|OFFLINE| Data Leaks & Hacktivism group ||
|https://t.me/GhostSecS|ONLINE|GhostSec Service|Ransomware, Exfiltration|
|https://t.me/+ghq2ayK6ybIwYmJi|EXPIRED| voidy - database storage||
|https://t.me/GitTools|ONLINE| ||
|https://t.me/gladdos69_official|ONLINE| DDoS |DDoS|
|https://t.me/GLORIAMISTS|OFFLINE|GLORIAMIST||
|https://t.me/glorysec|OFFLINE|GlorySec||
|https://t.me/goblins_gang|ONLINE| chat ||
|https://t.me/goblins_hub|ONLINE| hub links ||
|https://t.me/GoneTeam410|ONLINE|GoneTeam||
|https://t.me/GonjeshkeDarand|ONLINE| Gonjeshke Darande||
|https://t.me/grandgive|ONLINE| ||
|https://t.me/groupcracked|ONLINE|Group Ctacked||
|https://t.me/GroupLapsus|OFFLINE|Group Lapsus||
|https://t.me/gulfdocs|ONLINE| Data Leaks (Gulf Region), Middle East Document Dumps||
|https://t.me/+GxHjaDP0bOphZjNh|VALID| 8BASE Chat Group ||
|https://t.me/hackberegini|ONLINE|Beregini||
|https://t.me/hacker_trick|ONLINE| Hack Tricks||
|https://t.me/HackForceAll|OFFLINE|HackForce|R00TK1T ISC CYBER TEAM||
|https://t.me/hackgit|ONLINE| Offensive Security|
|https://t.me/hackingtoolsprvi8|OFFLINE| Leaks ||
|https://t.me/hack_n3t|ONLINE|HackNeT||
|https://t.me/hadesh0p|ONLINE| ||
|https://t.me/Handala_hack|OFFLINE|Handala Hack|Leaks & Breaches|
|https://t.me/hellokittyleaks|OFFLINE| Data Leaks ||
|https://t.me/hgn01_ru|OFFLINE| Data Leaks ||
|https://t.me/hidden_links|OFFLINE| Hidden Links ||
|https://t.me/highs0c1ety|OFFLINE|High Society|DDoS|
|https://t.me/HiveNETT|ONLINE|HiveNET||
|https://t.me/HK4GANG|ONLINE| ||
|https://t.me/hooshyarane|ONLINE|Hooshyaran-e Vatan group||
|https://t.me/HorusForumRus|ONLINE|Horus Forum||
|https://t.me/horus_reservs|ONLINE|Horus Evolution reserve||
|https://t.me/horusteam_officiall|ONLINE|Horus Evolution||
|https://t.me/horusteam_official|OFFLINE|Horus Evolution||
|https://t.me/HQ_COMBO|OFFLINE|Data Breaches Provider||
|https://t.me/HQCracking|ONLINE|Data Breaches Provider||
|https://t.me/HQPROX|ONLINE|Proxy service||
|https://t.me/hudyhstock|ONLINE| Selling Accounts ||
|https://t.me/Hunt3rkill3rs1|OFFLINE|Hunt3r Kill3rs||
|https://t.me/hydramarketrebuild|OFFLINE|Hydra Market Rebuild||
|https://t.me/icrewhackers|ONLINE| ||
|https://t.me/illsvcchat|ONLINE|Illicit Service chat||
|https://t.me/illsvcleaks|OFFLINE|Illicit Service Leaks||
|https://t.me/illsvcleaksupload|ONLINE|Illicit Service||
|https://t.me/illsvcleaksupload|ONLINE|Illicit Service Upload||
|https://t.me/illsvc|ONLINE|Illicit Service||
|https://t.me/INDIAN_CYBER_FORCE|ONLINE| ||
|https://t.me/Industrial_Spy|ONLINE| Industrial Spy ||
|https://t.me/infinity_hackers_group|ONLINE|Infinity Hackers By||
|https://t.me/INFINITY_HACKERSS|ONLINE|Infinity Forum||
|https://t.me/informZarya|OFFLINE|Zarya||
|https://t.me/InfraShutdown|OFFLINE|InfraShutdown - DDoS|DDoS|
|https://t.me/inj3ct0rs|ONLINE|Exploits Market and 0day Exploits Database||
|https://t.me/intelrepo|OFFLINE|Spectre's Intel Repository||
|https://t.me/intelx_io|OFFLINE| intelx - infosec||
|https://t.me/+ipEzVrjM43NkODc0|VALID| AKATSUKI gang (Algerian Ministry breach) ||
|https://t.me/itarmyofukraine2022|ONLINE| ||
|https://t.me/itsecalert|ONLINE| News ||
|https://t.me/+IYBPSRVwk6k4ZTEy|EXPIRED| Atlantis Cyber Army A.I.G. ||
|https://t.me/jambicyberteam|OFFLINE|Jambi Cyber Team||
|https://t.me/+jCjbvdsUSJIzN2Vl|VALID| The Collective Sentinel||
|https://t.me/jester_stealer_channel|ONLINE| Jester Stealer Channel |Infostealer|
|https://t.me/+JMruw9EHhWtmYjc9|EXPIRED| BlackDragonSec ||
|https://t.me/joinchat/8yMjCnT06ytjNzQx|EXPIRED| ||
|https://t.me/joinchat/AAAAAEedZM6cBNj764phgQ|EXPIRED|Large Hacking Group||
|https://t.me/joinchat/AAAAAFGhhcV9p1Rm2f_Emw|EXPIRED| ||
|https://t.me/joinchat/AAAAAFNLmVP0ZCy51tNOig|VALID| Forum ||
|https://t.me/joinchat/VBAj4Hc6Xki5lG_H|EXPIRED| Data Leaks ||
|https://t.me/joinchat/WCSE2vgon6IYGLgz|VALID| ||
|https://t.me/joinchat/xr2N5_kqYQE3ZDUy|EXPIRED|Kingsman||
|https://t.me/joinchat/YHUDj7dEmNE1NWQ0|EXPIRED| Data Leaks ||
|https://t.me/joinchat/YR89p_rg8Oo0Y2Ux|VALID| ||
|https://t.me/joker_reborn|ONLINE| Joker Reborn Redline Stealer |Infostealer|
|https://t.me/jokersworlds|OFFLINE|Joker's world of Free Database||
|https://t.me/jokmajd|ONLINE|TEAM1910||
|https://t.me/jsonc2|OFFLINE|jsonC2||
|https://t.me/JustAn0x|OFFLINE| Data Leaks ||
|https://t.me/justice_homeland|ONLINE|Homeland Justice||
|https://t.me/+k56KDQRn8FplN2Qy|VALID|PHOENIX||
|https://t.me/karakurt_news|ONLINE| Karakurt||
|https://t.me/kelvinsecuritydarkmarket|OFFLINE| Kelvin Security Dark Market||
|https://t.me/kiborg_leak|OFFLINE|Kiborg Leak (Alphabank)||
|https://t.me/killmilk_rus|ONLINE|DARKNET||
|https://t.me/killnet_channel|OFFLINE| ||
|https://t.me/KillnetChatLATAM|ONLINE|KillnetLATAM chat||
|https://t.me/KILLNETddos|ONLINE| Killnet DDoS |DDoS|
|https://t.me/KillnetLATAM|OFFLINE|KillneLATAM channel||
|https://t.me/killnet_mirror|ONLINE|Killnet mirror||
|https://t.me/Killneto|OFFLINE|Killnet Officiale (with invites for closed channel)|
|https://t.me/Killnet_Palestine|OFFLINE|Killnet Palestina||
|https://t.me/killnet_reservs|OFFLINE|Killnet reservs||
|https://t.me/king_0f_cracking|ONLINE|Free Data Breaches, cracking tools and proxy lists Provider||
|https://t.me/kittensec|ONLINE|KittenSec||
|https://t.me/Kristina_Pass_RF|OFFLINE| Data Leaks, Passport Scans||
|https://t.me/KryptonSolutions|OFFLINE|Krypton|DDoS|
|https://t.me/KryptonNetworks|OFFLINE|Krypton||
|https://t.me/lapsusfr|OFFLINE|LAPSUS$ France||
|https://t.me/Lapsussaudechat|OFFLINE| Lapsus$ channel (new) ||
|https://t.me/latestbin|ONLINE|Hacking Group||
|https://t.me/latest_leaks|ONLINE| Data Leaks||
|https://t.me/lazarus_apt18|ONLINE| Lazarus channel||
|https://t.me/LCdatabase|OFFLINE|Low-Cost-Database||
|https://t.me/Leak_23andme|ONLINE|23andme Leak Database||
|https://t.me/leakbaseforum|OFFLINE|LeakBaseForum||
|https://t.me/leakbase_official|OFFLINE|LeakBase Official||
|https://t.me/leakdataprivate|ONLINE| Data Leaks ||
|https://t.me/leak_db1|ONLINE|d3ltaboys group 1 (DB Leaks) - Backup||
|https://t.me/leak_db2|ONLINE|d3ltaboys group 2 (DB Leaks)||
|https://t.me/leak_db3|ONLINE|d3ltaboys group 3 (DB Leaks) - Backup||
|https://t.me/Leaked_BreachDBS|ONLINE|Leaks & Breaches||
|https://t.me/Leaked_Breached_Hacked_Database|ONLINE|Database of Data Breaches||
|https://t.me/Leaked_DataBase_Breached|OFFLINE| Data Leaks||
|https://t.me/leaked_databases|ONLINE| Data Leaks||
|https://t.me/leaked_detabase|ONLINE| Data Leaks ||
|https://t.me/LeakedSource|OFFLINE| Data Leaks||
|https://t.me/leakes4|OFFLINE| Data Leaks, Combo List||
|https://t.me/leakinformation|OFFLINE|Data Leaks||
|https://t.me/leaklicks|OFFLINE| Data Leaks||
|https://t.me/leaksdatabase|OFFLINE| Data Leaks||
|https://t.me/LeaksData|ONLINE| Data Leaks||
|https://t.me/leaksdirectory|OFFLINE|Leaks Directory||
|https://t.me/leaksmarts|ONLINE| Leaks Marts||
|https://t.me/leaksploit|OFFLINE| Data Leaks ||
|https://t.me/LeaRNEXploIT|ONLINE| ||
|https://t.me/LearnExploit|ONLINE| General hacking, Tutorials ||
|https://t.me/lefousamples|ONLINE| Data Leaks|
|https://t.me/LEGIONLEAKER|OFFLINE|Legion Leaker||
|https://t.me/Legion_Russia|OFFLINE| Legion Russia ||
|https://t.me/LegionServiceNewsGroup|ONLINE|Legion Service News Group|Data Leak|
|https://t.me/LionheartHACK|OFFLINE|Lionheart||
|https://t.me/LockBit_APT|ONLINE| LockBit APT ||
|https://t.me/lockbit_offical|OFFLINE|LockBit 3.0|Ransomware gang|
|https://t.me/LockBitSuppRaaS|OFFLINE|LockBitSupp|Ransomware gang|
|https://t.me/lulzsecmuslimsworld|ONLINE|Lulzsec Muslims||
|https://t.me/LulzSecOff|OFFLINE|LulzSec||
|https://t.me/LummaC2Stealer|OFFLINE|LummaC2 Stealer|Infostealer|
|https://t.me/LummaC2Team|OFFLINE|LummaC2 Stealer Chat|Infostealer|
|https://t.me/LummaReborn|OFFLINE|LummaC2 Stealer Channel|Infostealer|
|https://t.me/LummaTeam_Reborn|OFFLINE|LummaC2 Stealer Chat|Infostealer|
|https://t.me/+lYYyb3exPNFjNmRi|EXPIRED|Cyber Dragon||
|https://t.me/+LZQBX9ml0Qk3YWFl|EXPIRED|BF Repo V3 Chat||
|https://t.me/MAilAccessCracker|OFFLINE|Free Data Breaches Provider||
|https://t.me/mailaccesscrack|OFFLINE|Combo Lists||
|https://t.me/MaillAccessTop|OFFLINE| Data Leaks ||
|https://t.me/mailpasschanel|OFFLINE|Combo List||
|https://t.me/mailpassclub|OFFLINE| ||
|https://t.me/mailpasword|OFFLINE| ||
|https://t.me/malek_team1|OFFLINE|MalekTeam||
|https://t.me/MalwareForums|OFFLINE|Malware Forums||
|https://t.me/marketo_leaks|ONLINE| Data Leaks||
|https://t.me/Matryoshka424|ONLINE|Matryoshka424|DDoS|
|https://t.me/MBCRANSOMWARE|OFFLINE| Ransomware Gang||
|https://t.me/meganzshare|OFFLINE| ||
|https://t.me/membersofxaknet|ONLINE| ||
|https://t.me/meris_botnet|ONLINE|Meris botnet|DDoS|
|https://t.me/metastealer_official|ONLINE| Metastealer Officiale |Infostealer|
|https://t.me/MexicanMafiaTheShit|OFFLINE|MexicanMafia Announcement|Data Leak|
|https://t.me/MiladLeaks|ONLINE|Milad Leaks||
|https://t.me/milkdude|ONLINE| Data Leaks||
|https://t.me/minsaudebr|OFFLINE| Lapsus$ channel ||
|https://t.me/MysteriousTeam0|OFFLINE|Mysterious team bangladesh||
|https://t.me/naosbase|ONLINE|DB / Data Leak Search Engine||
|https://t.me/+nCFeH8PT-XUxZjEy|EXPIRED| Data Leaks||
|https://t.me/ndtgroup_kh|OFFLINE| ||
|https://t.me/NetHunt3r|ONLINE|NetHunt3r Group (pro Palestine)|Data Leak|
|https://t.me/NetHunt3r|ONLINE|NET Hunter||
|https://t.me/NetSurvivalist|ONLINE| General Hacking, Privacy ||
|https://t.me/net_worker_alliance|OFFLINE|Net Worker Alliance||
|https://t.me/NewBlood_Project|OFFLINE|New Blood Project||
|https://t.me/nightmare_hacker|OFFLINE|NIGHTMARE||
|https://t.me/NinjaByte|OFFLINE|Ninja Byte Combos (Combo Lists)|
|https://t.me/nn05716chat|ONLINE| NoName057(16) Eng||
|https://t.me/nohidespace|OFFLINE| Combo List ||
|https://t.me/noname05716engchat|ONLINE| NoName057(16) chat|DDoS|
|https://t.me/noname05716eng|OFFLINE| NoName057(16) Eng|DDoS|
|https://t.me/noname05716engversion|ONLINE|NoName057(16) Eng|DDos|
|https://t.me/noname05716|OFFLINE|NoName057(16) Rus|DDoS|
|https://t.me/noname05716reborn|OFFLINE|NoName057(16) Rus|DDoS|
|https://t.me/noname05716_reborn2|ONLINE|NoName057(16) Rus|DDoS|
|https://t.me/NNM05716Versioneitaliana|OFFLINE|NoName057(16) Ita|DDoS|
|https://t.me/noname05716versione_italiana|ONLINE|NoName057(16) Ita|DDoS|
|https://t.me/noname05716_version_espanola|OFFLINE|NoName057(16) Esp|DDoS|
|https://t.me/nnm05716esp|ONLINE|NoName057(16) Esp|DDoS|
|https://t.me/NullLeak|OFFLINE| Data Leaks ||
|https://t.me/O1chat|OFFLINE| Market ||
|https://t.me/+O7yT5lylY89lMTcy|VALID|TCG||
|https://t.me/ObserverCloud|OFFLINE| Observer Cloud Redline Stealer (Harvests other channels) |Infostealer|
|https://t.me/OBSERVERCLOUDCOMBO|OFFLINE|Combo List||
|https://t.me/OfficialBaphomet|ONLINE|BaphometOfficial||
|https://t.me/OnePlusChat|ONLINE| ||
|https://t.me/opendataleaks|OFFLINE| Data Leaks ||
|https://t.me/openleak|OFFLINE| Data Leaks ||
|https://t.me/OPRATIONSALIGATOR|ONLINE|Aligator Black Hat||
|https://t.me/Osintcorp_chat|ONLINE|OsintCorp||
|https://t.me/Osintcorp_chat|ONLINE|OsintCorp Group Chat||
|https://t.me/+paglZbHnhE8xMTA8|EXPIRED| Adrastea Group||
|https://t.me/Patriot_Black_Matrix|OFFLINE|Patriot Black Matrix||
|https://t.me/Patriot_Black_x|OFFLINE|Patriot Black Matrix||
|https://t.me/peass|ONLINE| ||
|https://t.me/phantom_tg|ONLINE| PHANTOM DEV ||
|https://t.me/phoenixinform|OFFLINE|Phoenix group||
|https://t.me/phoenix_inform|ONLINE|PHOENIX||
|https://t.me/Phorcy|ONLINE|Phorcy Stealer|Infostealer|
|https://t.me/poenamarket|ONLINE|Poena Market||
|https://t.me/privatecombos|OFFLINE| Data Leaks ||
|https://t.me/procoder_base|OFFLINE| Data Leaks ||
|https://t.me/proxy_bar|ONLINE| Exploits, Hacking and Leaks ||
|https://t.me/ProxyMTProto|ONLINE| ||
|https://t.me/pryntsktmarket|OFFLINE| Prynt Stealer Official|Infostealer|
|https://t.me/pwnwiki_zhchannel|ONLINE| ||
|https://t.me/QuartzSec|OFFLINE|QuartzSec||
|https://t.me/qZann|ONLINE| Data Leaks ||
|https://t.me/R00TK1TDB|OFFLINE| R00tk1t DB ||
|https://t.me/R00TK1TOFF |OFFLINE| R00tk1t Cyber Team ||
|https://t.me/+R1GELDqXo1dhMmYx|EXPIRED|Ziburate|Data Leak|
|https://t.me/raidsecretforums|OFFLINE| Claims to be the backup channel of RaidForums ||
|https://t.me/ransomblackbit30|OFFLINE|Lockbit 3.0 Main.js||
|https://t.me/ransom_house|OFFLINE| RansomHouse official channel ||
|https://t.me/RansomTeam|ONLINE|RansomTeam  Chat||
|https://t.me/RansomwareTeam|ONLINE| Ransomware Team||
|https://t.me/ransomwatcher|ONLINE| Data Leaks ||
|https://t.me/rdpstealer|ONLINE|Rdp Stealer|Infostealer|
|https://t.me/redstresserorg|OFFLINE|Meris botnet main channel|DDoS|
|https://t.me/reveng3rs|OFFLINE| Data Leaks ||
|https://t.me/revolusigbanon17|OFFLINE|GB Anon 17||
|https://t.me/RHA_Red_Hackers_Alliance_Russia|ONLINE| Data Leaks||
|https://t.me/russiagoodbuy_rgb_team|ONLINE|RGB Team (https://rgb-team.com)|Data Leak|
|https://t.me/+RxMyTFg9NYllZmU5|EXPIRED|Waus Leaks||
|https://t.me/sanaski|ONLINE| Configs, combos ||
|https://t.me/Sell_rdp1|OFFLINE| ||
|https://t.me/ServerKillers|ONLINE|Server Killers||
|https://t.me/shadowleakss|OFFLINE|ShadowHacker Leaks||
|https://t.me/shadowleakss|ONLINE|Shadow Leaks||
|https://t.me/shadowseekers5|ONLINE|Shadow Seekers|Data Leak|
|https://t.me/shieldteam1|ONLINE| ||
|https://t.me/ShizoPrivacy|ONLINE| 0% Privacy||
|https://t.me/SiegedSecc|OFFLINE|SiegedSec||
|https://t.me/SiegedSec|OFFLINE| Sieged Sec||
|https://t.me/SiegedSecurity|OFFLINE|SiegedSec||
|https://t.me/silentplug666|ONLINE| Market ||
|https://t.me/sixtysixdata|OFFLINE|66SLAVS Datagroup|Data Leak|
|https://t.me/SkidbinSITE|OFFLINE|Skidbin|Doxing|
|https://t.me/slivaidlocker|ONLINE| AiDLocker Group Data Leaks Channel||
|https://t.me/slivnoviy123|ONLINE| Erernity Team Redline Stealer|Infostealer|
|https://t.me/SNAKEDBS|OFFLINE|Nuttela Combo's (Repackaged Combo Lists)||
|https://t.me/snatch_info|ONLINE|Snatch ransomware gang|Ransomware, Exfiltration|
|https://t.me/snatch_news|ONLINE| Snatch Team (Ransomware Gang) ||
|https://t.me/Sn_blackmeta|OFFLINE|SN_ Blackmeta|DDoS|
|https://t.me/SN_Darkmeta|OFFLINE|SN_ Blackmeta|DDoS|
|https://t.me/solntsepekZ|ONLINE|Sandworm||
|https://t.me/SolomonUpdates|OFFLINE|Solomon market place updates||
|https://t.me/spamsmtpcombo|ONLINE| Combo List ||
|https://t.me/SparrowCorp|OFFLINE|SparrowCorp||
|https://t.me/+SrY0b7MukCVmNDk1|EXPIRED|22C||
|https://t.me/StealerStore|ONLINE| Stealer Store|Infostealer|
|https://t.me/stkdatabase|ONLINE| Mapper (former STK Database)||
|https://t.me/StormFreeConfig|OFFLINE| Configs, Combos ||
|https://t.me/SylhetGangSgOfficial|ONLINE|Sylhet Gang-SG||
|https://t.me/sysadminbd|ONLINE|Sysadmin||
|https://t.me/+T0l1VDuQzDpjYWQ0|EXPIRED| Data Leaks||
|https://t.me/tbotlist|ONLINE| Bots ||
|https://t.me/t_darknet|ONLINE|Illicit Service||
|https://t.me/TE1915|ONLINE|1915 team||
|https://t.me/team1916|OFFLINE|TEAM1916||
|https://t.me/TeamDemon|ONLINE|Illicit Service||
|https://t.me/teamimm0rtal|ONLINE| Team Imm0rtal channel ||
|https://t.me/TeamIndianCyberForce|ONLINE|Indian Cyber Force||
|https://t.me/teaminsanepk|OFFLINE|Team insane pk||
|https://t.me/Team_r70YEMEN|ONLINE|DDoS Hactivitsts|DDoS|
|https://t.me/techpwnews|ONLINE| News ||
|https://t.me/tengkorakcybercrewz|OFFLINE|TengkorakCyberCrew Official||
|https://t.me/tgcnnatgvctfenqwf|OFFLINE|Combo List||
|https://t.me/the_archivists_domain|OFFLINE| Source Code Dumps ||
|https://t.me/ThreatSec|ONLINE|ThreatSec||
|https://t.me/TigerElectronicUnit|ONLINE|Electronic Tigers Unit ||
|https://t.me/torlinks|OFFLINE| ||
|https://t.me/Turbotelproxy|ONLINE| The fastest Telegram proxies ||
|https://t.me/turkhckteam|ONLINE|Turk Hack Team||
|https://t.me/udacha123yes|OFFLINE| Ransomware Gang ||
|https://t.me/+uIojmLMIJz0yNzIy|VALID|Hunting for Data|Data Leak|
|https://t.me/UnsafeInternet|ONLINE| Data Leaks ||
|https://t.me/UPENBULLET|OFFLINE| Configs, checkers, combos ||
|https://t.me/user1_pycc|OFFLINE|user1|DDoS and Data Leak|
|https://t.me/usersec_chat|ONLINE|UserSec Chat||
|https://t.me/usersec_collective|OFFLINE|UserSec Collective||
|https://t.me/user_secc|OFFLINE|UserSec||
|https://t.me/user_sec|OFFLINE|UserSec||
|https://t.me/user_sec|OFFLINE|UserSec Killnet Affiliated||
|https://t.me/usersec_reservs|OFFLINE|UserSec Reserve||
|https://t.me/+uV_Lxf2uOHhkMjAy|VALID| Killnet Store Chat ||
|https://t.me/+Uxo9r92Ho5ZkYjdi|EXPIRED| KILLNET ||
|https://t.me/+UYKtaIt6KFGlFwBJ|EXPIRED| VIP Config - configs, combos, etc ||
|https://t.me/V3TerN|ONLINE| Devilzone (2) - configs, combos, etc ||
|https://t.me/vulzsec_official|OFFLINE| ||
|https://t.me/+WbDFfZ2OOvdjY2M0|EXPIRED|Deanon ClubV7||
|https://t.me/weareaig|ONLINE| Atlas Intelligence Group ||
|https://t.me/We_are_not_eternal|ONLINE| ||
|https://t.me/webpwn|ONLINE| Hacking, Privacy ||
|https://t.me/weedforumslol|OFFLINE|WeedSec||
|https://t.me/WeJustEvil|ONLINE|Just Evil||
|https://t.me/weleakdatabase|OFFLINE| Data Leaks ||
|https://t.me/win_def|ONLINE|Windef||
|https://t.me/windmarketo|ONLINE| Data Leaks ||
|https://t.me/WLDBackup|OFFLINE| Data Leaks ||
|https://t.me/+wlf3z9fVHqgzYzk1|EXPIRED| Darks chat||
|https://t.me/+Wr6WoTXzjk0zMWI0|EXPIRED|Hunt3r Kill3rs private group||
|https://t.me/wwhsmi|ONLINE| WWH Forum ||
|https://t.me/x7seller|OFFLINE|X7Root Seller||
|https://t.me/+x9tlrn-DoOw0NmNl|EXPIRED| Team BlackDragonSec ||
|https://t.me/xaknet_team|ONLINE| Killnet ||
|https://t.me/xaknet_team|ONLINE|Sandworm||
|https://t.me/xAnonymousSudan|OFFLINE|Anonymous Sudan||
|https://t.me/xGodzillAxChat|OFFLINE|Godzilla Botnet chat||
|https://t.me/xinject_official|ONLINE| (Dead)XInject Information Channel ||
|https://t.me/xxShad0dexx|OFFLINE|Shad0de||
|https://t.me/+y8c51prOz20wNWU0|EXPIRED|Solomon market place support||
|https://t.me/Yad2Leaks|OFFLINE| Data Leaks ||
|https://t.me/+YhH_DjYUyYpmNDRi|EXPIRED| Backup @HackGit channel||
|https://t.me/+ykoIXVJBirI0NzU0|EXPIRED|Leaks & Breaches||
|https://t.me/+YRLqvlnUI84zNzZl|EXPIRED|BF Repo V3 Files||
|https://t.me/+yXOcSjVjI9tjM2E0|EXPIRED|Medusa|| 
|https://t.me/zendatamarket|OFFLINE|ZenData Database Market||
|https://t.me/zer0daylab|OFFLINE| Hacking, Leaks and News ||
|https://t.me/zerodayforums|ONLINE| ZeroDay Forums ||
|https://t.me/zerodaymarkets|OFFLINE|Zeroday Market|Exploit sell|
|https://t.me/ZeroDay_TM|ONLINE| Original  ZeroDay  Community ||
|https://t.me/zolfcombo|OFFLINE|ZOLF Combos||
|https://t.me/ZulikGroupChat|ONLINE|ZulikGroup Chat||
|https://t.me/ZulikGroupTG|OFFLINE|ZulikGroup||
|https://t.me/D1rkSec|ONLINE|D1rkSec|Leaks & Breaches|
|https://t.me/logs_databases|OFFLINE|R.E.D. H.A.S.H.|Leaks & Breaches|
|https://t.me/DAEKLIKS|OFFLINE|Dark_leaks|Leaks & Breaches|
|https://t.me/combodatabasee|OFFLINE|COMBO DATABASE|combos|
|https://t.me/mailpass|OFFLINE|MAIL:PASS HQ Combos & Bases|combos|
|https://t.me/combosgrupoplex|OFFLINE|Combos grupo plex|combos|
|https://t.me/emailistsdatabase|ONLINE|Database Email Lists and Numbers Lists|combos|
|https://t.me/www_paypal|ONLINE|Pro Team Channe|combos|
|https://t.me/freshcombomails|OFFLINE|Fresh Combo mails|combos|
|https://t.me/GGBestCombo|OFFLINE|GGBestCombo|combos|
|https://t.me/+f6HgnXuFRiIxMzhk|VALID|Pro Team Channel|combos|
|https://t.me/Crackingcombolist|OFFLINE|Cracking Combo|combos|
|https://t.me/R3dd1sh_34_E4gl3_D4t4l34ks|OFFLINE|Ŕ€đďįşħ €ąğℓę ďάťάŁэάķş|combos|
|https://t.me/freecombosmails|OFFLINE|FREE COMBOS MAILS|combos|
|https://t.me/URLPASSCLOUD|OFFLINE|URL:USER:PASS CLOUD|combos|
|https://t.me/voltspammer|OFFLINE|VOLT CRACKS|combos|
|https://t.me/TEST123ND|OFFLINE|TEST|combos|
|https://t.me/logsgang2|ONLINE|Logs|combos|
|https://t.me/MailPassPrivates|OFFLINE|Mail Pass Privates|combos|
|https://t.me/mailaccessmegacloud|OFFLINE|MailAccess Mega Cloud|combos|
|https://t.me/DMMMMMM|ONLINE|BigDmtrydata|combos|
|https://t.me/FreeLogPassForAll|OFFLINE|FreeLog:PassForAll|combos|
|https://t.me/private_ratlogs|ONLINE|Free CLouds|combos|
|https://t.me/LegioNLeakeR|ONLINE|LegionLeaker|Exploit, Leakes & Breaches, combos, logs|
|https://t.me/plumdatabases|OFFLINE|Plum data bases|combos|
|https://t.me/easycloudlogsback0|ONLINE|Easy Cloud Logs Free|combos|
|https://t.me/PrivateCompanyPirates|ONLINE|PrivateCompanyPirates|combos|
|https://t.me/logsgang2|ONLINE|Logs|combos|
|https://t.me/COMBO_SOURCE|OFFLINE|COMBO PRIVATE|combos|
|https://t.me/emp_name|OFFLINE|EMP Group (EMailPass)|combos|
|https://t.me/azzasec|ONLINE|AzzaSec||
|https://t.me/lulzchat|OFFLINE|LulzSec chat||
|https://t.me/realLulzSec|OFFLINE|VSec||
|https://t.me/CyberVolk_K|OFFLINE|CyberVolk|dataleak|
|https://t.me/evilzoneforum|OFFLINE|Evil Zone|Forum|
|https://t.me/justice_homeland_original|ONLINE|HomeLand Justice||
|https://t.me/JusticeHomeland1|ONLINE|HomeLand Justice||
|https://t.me/Team1722|ONLINE|Team1722||
|https://t.me/hack_n3t|OFFLINE|HackNeT|DDoS|
|https://t.me/Alien_UFO_LEAKS|OFFLINE|UFO LEAK MARKET|Leaks & Breaches|
|https://t.me/sultengblackhat|ONLINE|INDONESIAN CYBER OF SULAWESI TENGAH BLACKHAT|Leaks & Breaches|
|https://t.me/OPRATIONSALIGATOR|ONLINE|ALIGATOR BLACK HAT|Leaks & Breaches|
|https://t.me/Leak_DBMS|ONLINE|Leak DBMS|Leaks & Breaches|
|https://t.me/LulzSec_Off|OFFLINE|PhantomGroup|Threat Actor|
|https://t.me/hackercouncil|ONLINE|Hacker Council Global|DDoS|
|https://t.me/dedsecc_official|OFFLINE|DedSec|DDoS|
|https://t.me/hackerforse|OFFLINE|7 October Union|DDoS|
|https://t.me/whoisAlixan|OFFLINE|AlixSec|Leaks & Breaches|
|https://t.me/StressedForums|OFFLINE|Stressed Forum|Forum|
|https://t.me/ddosiamonitor|ONLINE|DDoSia Target Monitor|DDoS|
|https://t.me/+rlyGuPTMGuU5YjE6|VALID|DDoSia Project|DDoS|
|https://t.me/h0lyleague|OFFLINE|Holy League|DDoS|
|https://t.me/Holy_League|ONLINE|Holy League|DDoS|
|https://t.me/+kcr0MVem9OA3MTk6|EXPIRED|Handala Hack|Leaks & Breaches|
|https://t.me/Handala_backup|OFFLINE|Handala Backup|Leaks & Breaches|
|https://t.me/azzasecurity|OFFLINE|Azzasec|DDoS|
|https://t.me/KozSec|OFFLINE|KozSec|DDoS
|https://t.me/KozSec1|OFFLINE|KozSec backup|DDoS|
|https://t.me/KozSecChat|OFFLINE|KozSec chat|DDoS|
|https://t.me/TG_SECurityTr8Ker|ONLINE|SECurityTr8Ker|SEC's RSS feed monitor|
|https://t.me/RipperSec|OFFLINE|RipperSec|DDoS|
|https://t.me/goripoolcodes|ONLINE|Goripool Codes|Phishing pages,panels|
|https://t.me/Anonymous_Guys_313|OFFLINE|Anonymous Guys|DDoS|
|https://t.me/+DZRa-yXaHZ81MmNk|EXPIRED|Handala Hack|Leaks & Breaches|
|https://t.me/CyberToufan|ONLINE|CyberToufan|Data Leaks|
|https://t.me/AlAhadSecurity|OFFLINE|Al Ahad|DDoS|
|https://t.me/ridgedforums|OFFLINE|BlackForums|Forum|
|https://t.me/thebrotherhoodcorp|ONLINE|The Brotherhood|Ransomware Gang|
|https://t.me/bloodforgex|OFFLINE|BloodForge|RaaS|
|https://t.me/RedEagleCrew|OFFLINE|Red Eagle Crew|DDoS & Data Breach|
|https://t.me/NetGhostSecurity|ONLINE|DDoS & Data Breach|
|https://t.me/Liquid_Blood|ONLINE|Liquid Blood|DDoS|
|https://t.me/AisData|OFFLINE|AisData|Data Breach|
|https://t.me/+NO_mK4lapd0yY2Vk|EXPIRED|NoName057 EN|DDoS|
|https://t.me/exodusmarketchannel|ONLINE|Exodus Logs Market|
|https://t.me/breachwatchers|ONLINE|Breach Watchers|Data Breach|
|https://t.me/TheMoskovskiTimes|ONLINE|The Moskovski Times|Data Breach|
|https://t.me/radnetbak|ONLINE|RADNET64|DDoS|
|https://t.me/cloudata_news|ONLINE|Cloudata News|Data Leaks|
|https://t.me/DragonRansom|ONLINE|Dragone RaaS|Ransomware Gang|
|https://t.me/OPRATIONSALIGATOR|ONLINE|Aligator Black Hat|Data Leaks|
|https://t.me/INDOHAXSEC|ONLINE|INDOHAXSEC|DDoS, Defacement & Data Breach|
|https://t.me/FreshAccess|OFFLINE|Venom Access Token|Initial Access|
|https://t.me/DangerZoneForum|ONLINE|Danger Zone Forum|Forum|
|https://t.me/fredensofsecurity1|OFFLINE|Fredens of Security|DDoS, Defacement & Data Breach|
|https://t.me/filehaus|ONLINE|Filehaus||
|https://t.me/esteemrestorationeagle|ONLINE|Esteem Restoration Eagle|Defacement & DDoS|
|https://t.me/nnm057_16|OFFLINE|NoName057(16)|DDoS|
|https://t.me/bratvacorp|ONLINE|Bratva||
|https://t.me/+NcyNWGFil7plYzNi|VALID|x0x0ba$e|Data Leaks|
|https://t.me/+lPVDPudjxSE0M2Q1|VALID|Data Globe|Data Breach|
|https://t.me/hack_0xTam|OFFLINE|0X_Team|DDoS, Defacement & Data Breach|
|https://t.me/AzzaSec_Off|OFFLINE|AzzaSec|DDoS|
|https://t.me/CyperBattle|ONLINE|Cyber Battle|DDoS|
|https://t.me/blackopmrhamza|OFFLINE|Mr Hamxa|DDoS|
|https://t.me/TeamARXU|OFFLINE|Team Arxu|DDoS & Data Breach|
|https://t.me/+QeVsxdEnla80NzY1|EXPIRED|DXPLOIT|Defacement|
|https://t.me/blackopmrhamza2|ONLINE|Mr Hamza||
|https://t.me/alixsecenglish|ONLINE|Alixsec|DDoS|
|https://t.co/L4BrdL3dyB|ONLINE|RootDoS|DDoS|
|https://t.me/AnonSecItaChat|ONLINE|Anonymous Italia Chat||
|http://t.me/AnonSecITA|ONLINE|Anonymous Italia Channel|
|https://t.me/+l2fmYlvJnTA2MTc0|VALID|Bucket Leaks|Data Leaks|
|https://t.me/SpidrXXX|ONLINE|Spider-X|DDoS|
|https://t.me/privetOTof222|ONLINE|OverFlame|DDoS|
|https://t.me/Laneh_dark|ONLINE|Laneh Dark||
|https://t.me/Laneh_news|ONLINE|Laneh News||
|https://t.me/LegionServiceNews|ONLINE|Legion Service News|News|
|https://t.me/varundb/|OFFLINE|VARUN|Data Leaks|
|https://t.me/+4CffqtOZoZwxMTcx|VALID|Handala|Ransomware gang|
|https://t.me/+02lgyxsgsyAwYmY0|Expired|Ddarknot||
|https://t.me/+tObrYXqGOetmODhl|VALID|AKU LAV 2||
|https://t.me/darkstormteambackup2|ONLINE|Dark Storm Team|DDoS|
|https://t.me/hackrsk70|ONLINE|Team K70|DDoS|
|https://t.me/Z_Pentest_Beograd|OFFLINE|Z-PENTEST Alliance|DDoS & Data Breach|
|https://t.me/z_pentest_reborn|ONLINE|Z-PENTEST Alliance|DDoS & Data Breach|
