|Link| Description |
| ------ | ------ |
|http://www.billkce2k4oxrrzg6whgrgp4bce36ipeye72hqnbsqdktzwbrgqhrcyd.onion|Sell counterfeit money|
|http://billkce2k4oxrrzg6whgrgp4bce36ipeye72hqnbsqdktzwbrgqhrcyd.onion|Sell counterfeit money|
|http://mhaus2lidy3mgkvb44voy4srrprxwqpfylafrsqzijgs2zkcsvuhslad.onion|Sell counterfeit money|
|http://i7tcahglbavwwsuiligonbgjlrioczryo5w35zw7przd2rjvtmcsinad.onion|Sell counterfeit money|
|http://nemesis555nchzn2dogee6mlc7xxgeeshqirmh3yzn4lo5cnd4s5a4yd.onion|Sell counterfeit money, drugs, hacking|
|http://g2a2ddehqk4vojtmktrirfgvwe3ntz6gue6nwbv5y64lgtug7iwfj7ad.onion|Sell counterfeit money|
|http://pasteboxx44wtzbm3ldjkcncls6uggi7mipmdwef5zza6wjqrqrtxdid.onion/paste.php?id=58345|Sell counterfeit national insurance number, green card|
|http://waoceduf7c2wci5gdnw2hkb2aiittb5gl53dz35ut4hzd72ucxnvk2qd.onion|Sell counterfeit passport, DL, ID|
