|Name|Status|Description|
| ------ | ------ | ------ |
|[0-DAY](https://0-day.shop)| ONLINE | |
|[Stealer credential leaks](https://whiteintel.io)| ONLINE | |
|[Darth maul shop](https://1977.ws/)| ONLINE | |
|[2EASY](https://2easy.shop)| OFFLINE | |
|[2EASY](https://2easy.cc)| ONLINE | |
|[ALLWORLDCARDS](https://href.li/?http://awcardsqtyy2nzjz4bqwbccvv6xr4bdcwcgfyewd7gsx5mhh63c2lsad.onion)| OFFLINE | |
|[AlphaBay (Dark i2p)](tnaefzkcnhryeusi7hdpqujqiqmnbtah3dmjcg3gvezohunjuxbq.b32.i2p)| ONLINE | |
|[AlphaBay (Dark Tor)](http://alphabay522szl32u4ci5e3iokdsyth56ei7rwngr2wm7i5jo54j2eid.onion)| ONLINE | |
|[Archetyp](http://4pt4axjgzmm4ibmxplfiuvopxzf775e5bqseyllafcecryfthdupjwyd.onion)| ONLINE | |
|[ARES](http://sn2sfdqay6cxztroslaxa36covrhoowe6a5xug6wlm6ek7nmeiujgvad.onion)| ONLINE | |
|[ASEAN](http://asap2u4pvplnkzl7ecle45wajojnftja45wvovl3jrvhangeyq67ziid.onion)| ONLINE | |
|[AUTHORIZE CVV](https://authorizecvv.io)| ONLINE | |
|[AUTHORIZE CVV](https://authorizecvv.cc)| ONLINE | |
|[Abacus](http://abacusall6l52n5gp357vpv4yjjvh6ewg65pjbfvacyqcldux66btlqd.onion)| ONLINE | |
|[BIDEN CASH (Dark Tor)](http://bidenjxwb7khlh3djrmi6zkkmggiuoh6cnxll7my7uk25ohe27pcfryd.onion)| ONLINE | |
|[BIDEN CASH (free CVV - dark web)](http://l5wy5mo2bqv4pm5ozschtmqool2uwju4emahlqzfxlwsdgxtppjcblad.onion)| ONLINE | |
|[BIDEN CASH (free CVV - deep web)](https://bidencash.st)| ONLINE | |
|[BIDEN CASH](https://bidencash.cards)| OFFLINE | |
|[B1ND.NET](https://b1nd.net)| ONLINE | |
|[BLACKBONES](https://blackbones.net)| ONLINE | |
|[BLACKPASS](http://blackpasspn7734jqltjj2qx4qez5gcpcwujuugymky3lzcmmcfpzbyd.onion)| ONLINE | |
|[BOHEMIA](http://bohemiaobko4cecexkj5xmlaove6yn726dstp5wfw4pojjwp6762paqd.onion)| ONLINE | |
|[BOHEMIA](http://bohemia65jifi6rj3dcvu23tks5teidk6wllndg62vb37f57e6ymtgid.onion)| ONLINE | |
|[BRAINSCLUB](https://brainsclub.to)| ONLINE | |
|[BRIAN'S CLUB](https://briansclub.cm)| ONLINE | |
|[BR0K3R](http://brok3r7bhcblynwpoymgarr6zwcy4ttfbhkhcmotz4lw2gcsuojgaeqd.onion/)| ONLINE | |
|[B-P Market](https://b-p.sale/)| ONLINE | |
|[CABYC](http://cabyceogpsji73sske5nvo45mdrkbz4m3qd3iommf3zaaa6izg3j2cqd.onion)| ONLINE | |
|[CARD STORE](https://carding.store)| ONLINE | |
|[CARD TEAM](https://card.ms)| OFFLINE | |
|[CARDER](https://carder.uk)| OFFLINE | |
|[CARDING TEAM](https://cardingteam.ru)| ONLINE | |
|[CARDMAFIA](https://cardmafia.cc)| OFFLINE | |
|[CARDVILLA](https://cardvilla.cc)| ONLINE | |
|[CARTEL](http://mgybzfrldjn5drzv537skh7kgwgbq45dwha67r4elda4vl7m6qul5xqd.onion)| OFFLINE | |
|[CLUB2CRD](https://club2crd.cc)| OFFLINE | |
|[CLUBV](https://clubv.su)| OFFLINE | |
|[CRIMEMARKET](https://crimemarket.is)| ONLINE | |
|[CRIMEMARKET (Dark)](http://crimemosjicmij6jqtwww7wm2rmor5ymrs6wha6tzyiisxhy34go5sid.onion/)| ONLINE | |
|[CVV SHOP DUMPS](http://masterc2oss6cmeiwd6hzz44ghjdvkw2og6zv5iczcrssrbkrbuhn3qd.onion)| ONLINE | |
|[CVVUNION](https://cvv-union.at)| OFFLINE | |
|[CYPHER](http://6c5qaeiibh6ggmobsrv6vuilgb5uzjejpt2n3inoz2kv2sgzocymdvyd.onion)| ONLINE | |
|[DAKC0DE](http://darkodemard3wjoe63ld6zebog73ncy77zb2iwjtdjam4xwvpjmjitid.onion)| OFFLINE | |
|[DARKCLUB](https://darkclub.pw/)| ONLINE| |
|[DARKCLUB (Onion Site)](http://darkclubolst4fiquh7eodn3gffa4jr3y6nrfdxxii3hboulgotjj4ad.onion)| ONLINE |
|[DARKCLUB (Onion Site 2](http://darkclub7swbzf2ndqowmijp735urtfv6vp5z327vdga5iltlwzyapid.onion//)| ONLINE |
|[DARK LEAK MARKET](http://aby6efzmp7jzbwgidgqc6ghxi2vwpo6d7eaood5xuoxutrfofsmzcjqd.onion)| ONLINE | |
|[DARK LEAK MARKET](http://darkleakyqmv62eweqwy4dnhaijg4m4dkburo73pzuqfdumcntqdokyd.onion)| ONLINE | |
|[DARK LEAK MARKET](http://darklmmmfuonklpy6s3tmvk5mrcdi7iapaw6eka45esmoryiiuug6aid.onion)| ONLINE | |
|[DarkSsasinsShop](http://dq7hdxbxxw4sjssigwq4tivo22dpurpy65f7xqqcdesf4jzq5tsh7did.onion/)| ONLINE | |
|[DARK ZONE](http://6bcecdo7ldzkudt6dnsuljqoyhgme4afsnytarre5nucjhgzmrn4txad.onion)| OFFLINE | |
|[DARKFOX MARKET](http://p5eg3xsssjglu6tvwfazp2nqqwfpah55wr3ljil2bezp5shix5ruqsqd.onion)| ONLINE | |
|[DATABASE](http://database6e2t4yvdsrbw3qq6votzyfzspaso7sjga2tchx6tov23nsid.onion)| ONLINE | |
|[Delta Marketplace](https://delta-marketplace.sellix.io/)| ONLINE | |
|[Dark Matter](http://darkmat3kdxestusl437urshpsravq7oqb7t3m36u2l62vnmmldzdmid.onion)| ONLINE | |
|[Dark Matter](http://darkmmk3owyft4zzg3j3t25ri4z5bw7klapq6q3l762kxra72sli4mid.onion)| ONLINE | |
|[Dark Matter](http://darkmmro6j5xekpe7jje74maidkkkkw265nngjqxrv4ik7v3aiwdbtad.onion)| ONLINE | |
|[DOCSHOP](https://doc-shop.ws)| OFFLINE | |
|[EMPIRE MARKET](http://2a2a2abbjsjcjwfuozip6idfxsxyowoi3ajqyehqzfqyxezhacur7oyd.onion)| ONLINE | |
|[ETERNITY](http://malwarewrn7fvd7zq243d74dxs3ca4wh5kw6i2opkzeusuoajtd2j5yd.onion)| ONLINE | |
|[EXODUS MARKET](https://exodusmarket.io)| ONLINE | |
|[EXODUS MARKET](https://exodusmarket.vc)| ONLINE | |
|[EXODUS MARKET](http://exodusyzzpcnxxvpqoyyv3g4yvcy2zbfj4u7jxb56mlcfguqvehyjeqd.onion)| ONLINE | |
|[FREDDY](freddy.atshop.io)| ONLINE | |
|[FreshTools](https://freshtools.net)| ONLINE | |
|[Genesis Market](https://genesis.market)| OFFLINE | | Put offline by FBI.
|[Genesis Market](https://g3n3sis.pro)| OFFLINE | | Put offline by FBI.
|[Genesis Market](https://g3n3sis.org)| OFFLINE | | Put offline by FBI.
|[Genesis Market (Tor v3)](https://genesis7zoveavupiiwnrycmaq6uro3kn5h2be3el7wdnbjti2ln2wid.onion)| OFFLINE | |
|[HYDRA (Deep)](https://hydramarket.co)| ONLINE | |
|[HYDRA (Tor v2)](http://hydra3rudf3j4hww.onion)| OFFLINE | |
|[HYDRA (Tor v3)](http://hydraclubbioknikokex7njhwuahc2l67lfiz7z36md2jvopda7nchid.onion)| OFFLINE | |
|[INDUSTRIAL SPY](http://spyarea23ttlty6qav3ecmbclpqym3p32lksanoypvrqm6j5onstsjad.onion/user/login)| ONLINE | |
|[INFINITY SHOP](http://infinityvzoe2ldb74y2klk7cs3nda2n3qozdy7sdgfouqrzfkp64sid.onion)| ONLINE | |
|[Intel Repository](http://intelrepository.com/)|ONLINE|Sale of Defense Contractor and Military Files|
|[Iran Info Marketplace](http://marketir7joj2ibuouojg2nwkdwfal5dhisp3g246jl4ur7r7zfvloid.onion)| ONLINE | |
|[LIBERTY](http://liberty4mhc252jcz6acjndbotamlajtoo43qcmz4i62lc4b2ol4aeyd.onion)| OFFLINE | |
|[LOLZ.GURU](https://lolz.guru/)| ONLINE | |
|[LOCKDATA AUCTION](http://wm6mbuzipviusuc42kcggzkdpbhuv45sn7olyamy6mcqqked3waslbqd.onion)| OFFLINE | Probably a scam website. |
|[LuxeCC](https://luxecc.net)| ONLINE | |
|[MAGBO (Dark)](http://magbocc3tco4vmxx.onion)| OFFLINE | |
|[MAGBO (Deep)](https://magbo.shop)| ONLINE | |
|[MegaCiti](http://ba72lxa2o2qxqixzeubnbookar2kssk42ds63m2qvlnr7b4oqtyayvad.onion)| ONLINE | |
|[MGM GRAND](http://wghtttq3gkw2leaio5umqa2lqbjm4qcdhr4v5jj3ftirohx3hfp62eyd.onion)| ONLINE | |
|[MONOPOLY](http://monopolydc6hvkh425ov6xolmgx62q2tgown55zvhpngh75tz5xkzfyd.onion)| OFFLINE | |
|[NEXUS](http://nexus2bmba34euohk3xo7og2zelkgbtc2p7rjsbxrjjknlecja2tdvyd.onion/categoria-produto/malware)|ONLINE | |
|[NOHIDE](https://nohide.space)| ONLINE | |
|[ODIN](https://odin.to)| OFFLINE | |
|[ODIN](https://odin.pw)| ONLINE | |
|[ODIN](https://odin.pm)| ONLINE | |
|[ODIN](https://odinshop.io)| ONLINE | |
|[ODIN](https://odinshop.se)| ONLINE | |
|[ODIN](https://odinshoyi3y5clejn3klyggxrmq5sy5efdiremz353z6ucdujgdiccad.onion)| ONLINE | |
|[ONI.GG](https://oni.gg) ONLINE | https://t.me/oniforum - https://t.me/onichatter |
|[ONLYONE](https://only-one.cc)| OFFLINE | |
|[ORVX SHOP](https://orvx.pw/)| ONLINE | |
|[Pois0n](https://pois0ncc.ru)| ONLINE | |
|[PROBIV](https://probiv.one)| ONLINE | |
|[RESCATOR](https://rescator.cn)| ONLINE | |
|[RESCATOR (Tor v3)](http://rescatorfof3pwgux4olwxxcd22yjtuj72kmdltyr6tsr6jfohpnhead.onion)| ONLINE | |
|[RONDA STORE (Deep - mirror)](https://rondastore.vip)| ONLINE | |
|[RONDA STORE (Deep)](http://rondastore.cc)| ONLINE | |
|[RONDA STORE (Tor v3)](http://r4hyxmieadsyhnqzccmib45qtwa3x74gpnp24ovicuiuc5jzj3jxj2ad.onion)| ONLINE | |
|[Royal Market (Tor v3)](http://royalyygxzq5fadtlgzftq3dwpdycq4gvddmvhrk3l2gjzsfqqwpvwad.onion)| ONLINE | |
|[Russian Market (Deep)](https://russianmarket.gs)| OFFLINE | |
|[Russian Market (Deep)](https://russianmarket.to)| OFFLINE | |
|[Russian Market (Deep)](https://russianmarket.io)| REDIRECT TO TOR | |
|[Russian Market (Deep)](https://russianmarket.vc)| ONLINE | |
|[Russian Market (Deep)](https://rm1.to)| ONLINE | |
|[Russian Market (Deep)](https://rm1.vc)| ONLINE | |
|[Russian Market (Tor v2)](http://rusmarkethgwhfbn.onion)| OFFLINE | |
|[Russian Market (Tor v3)](http://flydedxmmddhgt3vfhv6om63ra2u2x4jxginulhxb6nzcnj3wwgavwyd.onion)| ONLINE | |
|[Russian Market (Tor v3)](http://rumarkstror5mvgzzodqizofkji3fna7lndfylmzeisj5tamqnwnr4ad.onion)| ONLINE | |
|[SHADOWCARDERS](https://shadowcarders.com)| ONLINE | |
|[SOLOMON](http://si3ttdyjjv63plkkwjlriztnwe5lb4ytke3llowegad4hdqfd5sm32yd.onion)| ONLINE | |
|[SOLOMON](http://solozr5dlwosdsfwtem4yfmpfh6orhzee7dbpv4dsjdsthnlur4cguqd.onion)| ONLINE | |
|[STYX](https://styxmarket.com)| ONLINE | |
|[SWIPESTORE](https://swipestore.cc)| ONLINE | |
|[THEMAJESTIC](http://tmglsdiax6dhx6iasbrokghhv7553a4cqc374tcgkvgl3xmp6z5t5myd.onion)| ONLINE | |
|[TOOREZ](http://lstkx6p3gzsgfwsqpntlv7tv4tsjzziwp76gvkaxx2mqe3whvlp243id.onion)| OFFLINE | |
|[TOR2DOOR](http://orn3olemwhrsqbpz7iv34mjzare6sns5z75rea3qzwqlle76wxsdzeqd.onion)| OFFLINE | |
|[UAS RDP SHOP](http://2x4tmsirlqvqmwdz.onion)| ONLINE | |
|[UniCC](https://unicvv.ru)| ONLINE | |
|[VICE CITY](http://vice2e3gr3pmaikukidllstulxvkb7a247gkguihzvyk3gqwdpolqead.onion)| ONLINE | |
|[VICE CITY](http://viceagrs476vms3hlgotcimao4lwnpz2ffpvgbdnbeqwu74g47z4usyd.onion)| ONLINE | |
|[VICE CITY](http://vice3nwnin46cmmvg4j3wd3xguaaiwlwzxt2mxkd5ng6ougfcu4rdfid.onion)| ONLINE | |
|[Wannabuy RDP](http://wannab666qqm2nhtkqmwwps3x2wu2bv33ayvmf4jyb6g3ibmitdzkcyd.onion)| ONLINE | |
|[WAUS LEAKS](https://wausleaks.com)| OFFLINE | |
|[WAUS LEAKS(new)](https://waus.io)| OFFLINE | |
|[WAUS LEAKS(new)](http://waus.ninja)| ONLINE | |
|[WAUS LEAKS(new)](http://waus.me)| ONLINE | |
|[WHM market (1)](http://76p5k6gw25l5jpy7ombo2m7gt4zppowbz47sizvlzkigvnyhhc26znyd.onion)| OFFLINE | |
|[WHM market (2)](http://auzbdiguv5qtp37xoma3n4xfch62duxtdiu4cfrrwbxgckipd4aktxid.onion)| OFFLINE | |
|[WINXXX (Dark)](http://cvvamoggrcopaeehscyic6xu3q5lbameo3kv3q3ptpfa5bsq2vrbjsad.onion)| ONLINE | |
|[WINXXX (Deep)](https://cvv.ms)| ONLINE | |
|[XLEET (Dark)](http://xleetg4krpki4irlaelwacpfhfxnhpizuipxc7f3aztu7265fqvinfad.onion)| ONLINE | |
|[XLEET (Deep)](https://xleet.is)| ONLINE | |
|[ZISMO](https://zismo.biz)| ONLINE | |
|[FIREARMS 72 (Deep)](http://fa72ibhl677j77dq4rt6bmiplwhpfymq2glwl5e2i563vkrcg4elfkyd.onion)| ONLINE | |
|[CAREBBAEN (Deep)](http://cardpl74ltmwe4o7pgpefljcng6qr36cnn7gzer2wermedxz3volxkqd.onion)| ONLINE | |
|[VORON MARKET (Deep)](http://vorodtm2plbuobna3wmkifs53saq4mlv5v7ye5ltj25puxsbt7hdrwqd.onion)| ONLINE | |
|[WOLF BANK HACKER (Deep)](http://wolft3xm254bvmv63hoe5v66kazyp7qoy2donh6fniwhur3qfynwljad.onion)| ONLINE | |
|[DARK TOOLS (Deep)](http://darkhuo35yiohrsdlbdhhrtl5ds7jtv5x2cjusqqebalj5vtrdqgqoid.onion)| ONLINE | |
|[UNDERGROUND MARKET (Deep)](http://undeb6m465pjocdl6kvyiwefj5xxzcu3hgzngpfe5eolw764suu5v3id.onion)| ONLINE | |
|[CC SALE (Deep)](http://csalryx3xenotyljyttsju6jfthrjyt6ijwd3zzykhkpyfoeao2nxaqd.onion)| ONLINE | |
|[CREDIT CARD DUMPS (Deep)](http://cdumhlyjn3q6rzed5jtqzramrtznaahics5d2zhpspstw5stfkew3qqd.onion)| ONLINE | |
|[PREPAID CARD STORE (Deep)](http://preplyqxgvapegf44xvv3c2kgccyi7enmcbqpck63j54c6av4fj2e2qd.onion)| ONLINE | |
|[Savastan0](https://savastan0.tools/)|ONLINE||
|[Hustlers](https://hustlers.ly/)|ONLINE||
