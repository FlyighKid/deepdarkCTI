|Name|Status|Description|
| ------ | ------ | ------ |
|[0x00sec](https://0x00sec.org/)|OFFLINE|
|[4CHEAT](https://4cheat.ru/)|ONLINE||
|[589forum](https://589forum.org/)|ONLINE|
|[AGAINSTTHEWEST](http://giphvoitymatg4cv7bxqh5dz6sn6bfscywoat4qtslztkomf5lavrayd.onion) | OFFLINE | |
|[ALLIGATOR](https://alligator.cash/)|ONLINE||
|[ALTENEN (Deep)](https://altenens.is)| ONLINE | |
|[Antichat](https://forum.antichat.com) | ONLINE | |
|[ANTIMIGALKI](https://antimigalki.space)| ONLINE | |
|[ARBITRAJ](https://arbitraj-forum.ru)| ONLINE | |
|[ASCARDING](https://ascarding.com)| ONLINE | |
|[ASTROPID](https://astropid.net)| ONLINE ||
|[BDF CLUB](https://bdfclub.com)| ONLINE | |
|[BEST CARDING WORLD](http://bestteermb42clir6ux7xm76d4jjodh3fpahjqgbddbmfrgp4skg2wqd.onion) | ONLINE | |
|[BHC Forums](https://bhcforums.cc) | ONLINE | |
|[BHF](https://bhf.ee)| ONLINE | |
|[BHF](https://bhf.im)| ONLINE | |
|[BHF](https://bhf.io)| OFFLINE | |
|[BITCOINFO.RU](http://bitcoinfor.ru)|ONLINE||
|[BITS.MEDIA](https://forum.bits.media)|ONLINE||
|[BLACKBIZ](https://blackbiz.top)|ONLINE||
|[BLACKBONES](https://blackbones.net)|ONLINE||
|[BLACKFORUMS](https://blackforums.me)| ONLINE | |
|[BLACKFORUMS](https://blackforums.net)| ONLINE | |
|[BLACKFORUMS](https://blackforums.ru)| ONLINE | |
|[BLACKHACKER](https://blackhacker.pw)|ONLINE||
|[blackhatpakistan](https://blackhatpakistan.net)| ONLINE | |
|[blackhatprotools](https://www.blackhatprotools.info/)| ONLINE | |
|[BLACKHATWORLD](https://blackhatworld.com)| ONLINE | |
|[BREACHED (Dark)](http://breached65xqh64s7xbkvqgg7bmj4nj7656hcb7x4g42x753r7zmejqd.onion)| OFFLINE | |
|[BREACHED (Deep)](https://breached.co)| OFFLINE | |
|[BREACHED (Deep)](https://breached.to)| OFFLINE | |
|[BREACHED (Deep)](https://breached.vc)| OFFLINE | |
|[BreachForums (Dark)](http://breached4w3qphorxg2fwqkhpfnsyf65je72d2shli3fcfgorwdeymad.onion)| OFFLINE | |
|[BREACH FORUMS (Dark)](http://breachedu76kdyavc6szj6ppbplfqoz3pgrk3zw57my4vybgblpfeayd.onion)| OFFLINE (seized) | |
|[BREACH FORUMS (Dark)](http://breached26tezcofqla4adzyn22notfqwcac7gpbrleg4usehljwkgqd.onion)| ONLINE | |
|[BREACH FORUMS](https://breachforums.cx)| OFFLINE | |
|[BREACH FORUMS](https://breachforums.is)| OFFLINE | |
|[BREACH FORUMS](https://breachforums.st)| ONLINE | |
|[BREACH FORUMS](https://breachforums.vc)| OFFLINE | |
|[BREACH FORUMS](https://breachforums.vc/) | OFFLINE | |
|[BTTFORUM](https://btt-club.top)| OFFLINE | |
|[CARDERS.BIZ](https://carders.biz)| ONLINE | |
|[CARDING FORUM (Deep)](https://cardingforum.cx)| OFFLINE | |
|[CENTER CLUB](https://center-club.io)| ONLINE | |
|[CHITACHOK](https://chitachok.ru)| ONLINE | |
|[COMFYBOX](https://comfybox.floofey.dog)| ONLINE | |
|[COOKIEPRO](https://coockie.pro)| ONLINE | |
|[CRACKED](https://cracked.io)| ONLINE | |
|[CRACKING](https://cracking.org) | ONLINE | |
|[CRACKING KING](https://crackingking.com)| OFFLINE | |
|[CRACKING MAFIA](https://crackingmafia.is)| ONLINE | |
|[CRACKING PRO](https://www.crackingpro.com)| ONLINE | |
|[CRACKING X](https://crackingx.com)| ONLINE | |
|[CRAX PRO](https://crax.pro)| OFFLINE | |
|[CRDCLUB (Dark)](http://crdclub4wraumez4.onion)| OFFLINE | |
|[CRDCLUB](https://crdclub.su)| OFFLINE | |
|[CRDPRO](https://crdpro.cc)| ONLINE | |
|[CRIMENETWORK (Dark)](http://cnw4acab23przeum6ios6pw63ivxxbrvpclz5yssflkos6ano6oq4fqd.onion)| ONLINE | |
|[CRIMENETWORK (Deep)](http://crime.to)| ONLINE | |
|[CRIMENOW](http://crimenow.is)| ONLINE | |
|[CRIMESTATE](https://crimestate.cc)| ONLINE | |
|[CRYPTBB](http://cryptbbtg65gibadeeo2awe3j7s6evg7eklserehqr4w4e2bis5tebid.onion)| ONLINE | |
|[CRYPTOCURRENCY.TECH](https://forum.cryptocurrency.tech)| ONLINE | |
|[CRYPTOFF](https://forum.cryptoff.org)| ONLINE | |
|[CRYPTOGID](http://cryptogid.org)| ONLINE | |
|[CVV_BOARD](https://cvvbrd.info)| ONLINE | |
|[CYBHACK](https://cybhack.net)| ONLINE | |
|[D4rkForums](https://d4rkforums.net)| ONLINE | |
|[DANGEROUSTHINGS](https://forum.dangerousthings.com)| ONLINE | |
|[DARK2WEB](https://dark2web.net)| ONLINE | |
|[DARKCLUB](https://darkclub.pw)| ONLINE | |
|[DarkForum](https://darkforum.in)| ONLINE | |
|[DARKFORUM](https://darkforum.net)| ONLINE | |
|[DARKFORUMS](https://darkforums.me)| OFFLINE | |
|[DARKFORUMS](https://darkforums.st)| ONLINE | |
|[DARKMARKET.AT](https://darkmarket.at)| OFFLINE | |
|[DARKMARKET.CX](https://darkmarket.cx)| OFFLINE | |
|[DARKMONEY](https://darkmoney.lc)| ONLINE | |
|[DARKNET ARMY](http://dna777ucpo4unwxrzw5mzs4iqm5qz3uepw3k5mvwbt7tnufryvsgy5yd.onion)| ONLINE | |
|[DARKNET](https://darknet.ug)| ONLINE | |
|[DARKNETWORLD](https://www.darknetworld.com)| OFFLINE | |
|[Darkpid](https://darkpid.com) | ONLINE | |
|[darkpro](https://darkpro.net/)| ONLINE | |
|[DARKSIDE](https://www.dark-side.black)| OFFLINE | |
|[DARKWEB](http://dwforumuugiyderhybcpfxmlmoawgq6z3w6hk45nrnem3p7kwszhybad.onion)| ONLINE | |
|[DARKZONE](https://darkzone.uk)| ONLINE | |
|[DATACLOUD](https://datacloud.space)| ONLINE | |
|[DataForums](https://dataforums.co)| ONLINE | |
|[DEDICATET](https://dedicatet.com)| ONLINE | |
|[DEFCON](http://ezdhgsy2aw7zg54z6dqsutrduhl22moami5zv2zt6urr6vub7gs6wfad.onion)| OFFLINE | |
|[DEMONFORUMS](https://demonforums.net)| ONLINE | |
|[DRDARK](https://drdark.ru)| ONLINE | |
|[DREAD](http://dreadytofatroptsdj6io7l3xptbet6onoyno2yv7jicoxknyazubrad.onion)| OFFLINE | |
|[DREAD](http://g66ol3eb5ujdckzqqfmjsbpdjufmjd5nsgdipvxmsh7rckzlhywlzlqd.onion)| ONLINE | |
|[DUBLIKAT.CLUB](https://at.dublikat.club)| ONLINE | |
|[DUBLIKAT.PRO](https://my.dublikat.pro)| OFFLINE | |
|[DUMPED](https://dumped.to)| ONLINE| |
|[DUMPFORUMS (Dark)](http://cwtvplqgymm3kbzj7g2qijhpau4tcco52qwvkm66k357svomp5bw5eqd.onion/)| ONLINE | |
|[DUMPFORUMS (Deep)](https://dumpforums.to/)| ONLINE | |
|[DWF (Tor v2)](http://dwforumsmrcqdnt3.onion)| OFFLINE | |
|[DWF (Tor v3)](http://dwforumuugiyderhybcpfxmlmoawgq6z3w6hk45nrnem3p7kwszhybad.onion)| ONLINE | |
|[ELEAKS](https://eleaks.to)| ONLINE | |
|[ENCLAVE](https://www.enclave.cc)| ONLINE | |
|[ENDWAY](https://endway.su)| ONLINE | |
|[ETERNIA](https://eternia.to)| ONLINE | |
|[EVILARMY](https://evilarmy.in)| ONLINE | |
|[EVILZONE](https://evil-zone.org)| ONLINE | |
|[evilx](https://evilx.su/forum/)| ONLINE | |
|[EXPLOIT.IN (Dark)](https://exploitivzcm5dawzhe6c32bbylyggbjvh5dyvsvb5lkuz5ptmunkmqd.onion)| ONLINE | |
|[EXPLOIT.IN (Deep)](https://exploit.in)| ONLINE | |
|[EXPLOITS.WS](https://exploits.ws)| ONLINE | |
|[ezcarder](https://ezcarder.is/)| ONLINE | |
|[FORUMTEAM.ONLINE](https://forumteam.online)| ONLINE | |
|[FORUMTEAM.TOP](https://forumteam.top)| ONLINE | |
|[FSSQUAD](https://fssquad.com)| ONLINE | |
|[Funksec Ransomware](http://7ixfdvqb4eaju5lzj4gg76kwlrxg4ugqpuog5oqkkmgfyn33h527oyyd.onion/)| ONLINE | |
|[G0D.ONE MARKET](https://www.g0d.one)| OFFLINE | |
|[GERKI](http://gerkipwhfuqeeizl.onion)| OFFLINE | |
|[GETREKT](https://getrekt.io)| ONLINE | https://t.me/getrektio |
|[HACKFORUMS](https://hackforums.net/index.php)| ONLINE | |
|[hackingfather](https://hackingfather.com/)| ONLINE | |
|[hackonology](https://hackonology.com/forum/)| ONLINE | |
|[hacksnation](https://hacksnation.com/)| ONLINE | |
|[HACKTOWN](http://hacktowns3sba2xavxecm23aoocvzciaxirh3vekg2ovzdjgjxedfvqd.onion/HackTown.html)| ONLINE | |
|[HELIUM](http://fahue6hb7odzns36vfoi2dqfvqvjq4btt7vo52a67jivmyz6a6h3vzqd.onion/login)| ONLINE | |
|[HOHEKAMMER](http://hohekammer.cc)| ONLINE | |
|[IFUD](https://ifud.cx)| OFFLINE | |
|[IN4BZ](https://in4.bz)| ONLINE | |
|[INCIDIOUS](https://incidious.se) | ONLINE | |
|[INFECTED ZONE](https://infected-zone.com)| ONLINE | |
|[INFINITY](https://infinity.ink)| ONLINE | |
|[ITALIAN DARKNET COMMUNITY 3.0 (Dark)](http://dhri7ogvfpnflpkj3sc5x7umjl4gd26bkukzotbwdy76yjp5qvhjzmqd.onion)| OFFLINE | |
|[KCC](http://kcc.cat)| ONLINE | |
|[KICKASS](http://o3nqszgvtqwcc2mxqcqgeyulkh6spiv6yaahgu7znaphzmikfvpu5aad.onion)| ONLINE | |
|[KKKSecForum](https://forum.kkksec.com)| ONLINE | |
|[KOROVKA](http://korovka.cc)| ONLINE | |
|[Korovka](https://korovka.cc) | ONLINE | |
|[Lampeduza](https://lampeduza.la) | ONLINE | |
|[LEAD LAB](https://leadlab.top)| ONLINE | |
|[LEAKBASE](https://leakbase.cc)| OFFLINE | |
|[LEAKBASE](https://leakbase.io/)| ONLINE | |
|[LEAKBASE](https://leakbase.org)| ONLINE | |
|[LEAK FORUMS](https://leakforums.su)| ONLINE | |
|[LEAKS.SO](https://leaks.so)| ONLINE | |
|[LEAKS.SX](https://leak.sx)| ONLINE | |
|[LEAKY.PRO](https://leaky.pro/)| ONLINE | |
|[LEECH](https://leech.is)| ONLINE | |
|[LeVeL23HackTools](https://level23hacktools.com/hackers)| ONLINE | |
|[LinkPass](https://linkpass.info)| ONLINE | |
|[LOLZ](https://lolz.guru)| ONLINE | |
|[LOWENDTALK](http://lowendtalk.com)| ONLINE | |
|[MAILPASS](https://mailpass.club)| OFFLINE | |
|[MASTODON](https://masthead.social/auth/sign_in)| ONLINE | |
|[MEGATOP](https://megatop.biz)| ONLINE | |
|[MIPPED](https://mipped.com)| ONLINE | |
|[MMGP](https://mmgp.com)| ONLINE | |
|[MONEYDARK](https://moneymn.club)| OFFLINE | |
|[NEFARIUM](http://zcfl6nxpefzmythaqbqi7s3fgjsb4tobp7stonwaqrhtza7yn3ztijid.onion)| ONLINE | |
|[NEXTGEN FORUMS](https://NextGenForums.cc)| ONLINE | |
|[NIFLHEIM.TOP](https://niflheim.top)| ONLINE | |
|[NIGGAFORUMS (BLACKFORUMS MIRROR)](https://niggaforums.me)| ONLINE | |
|[NIGGAFORUMS (BLACKFORUMS MIRROR)](https://niggaforums.net)| ONLINE | |
|[NITTER](http://3nzoldnxplag42gqjs23xvghtzf6t6yzssrtytnntc6ppc7xxuoneoad.onion/)| OFFLINE | |
|[NODO313](http://nodo313.net)| ONLINE | |
|[NOHIDESPACE](https://nohide.space)| ONLINE | |
|[NULLEDBB](https://nulledbb.com)| ONLINE | |
|[NULLED](https://www.nulled.to)| ONLINE | |
|[OGUSERS](https://www.ogusers.com)| OFFLINE | |
|[OLVX](https://olvx.cc)| ONLINE | |
|[OMERTA](https://omerta.cc)| ONLINE | |
|[OMERTA](https://omerta.cx)| ONLINE | |
|[OMERTA](https://omerta.wf)| OFFLINE | |
|[OMERTA](https://omert.cc)| ONLINE | |
|[OnniForums](https://onniforums.com) | ONLINE | |
|[OPENSSOURCE](https://openssource.org)| ONLINE | |
|[PATCHED.TO](https://patched.to)| ONLINE | |
|[PAYLOAD.SH](https://payload.sh)| ONLINE | |
|[PHREAKER](https://phreaker.info)| ONLINE | |
|[PIRATEBUHTA](https://s1.piratebuhta.net)| ONLINE | |
|[PROBIV](https://probiv.one)| ONLINE | |
|[PROCRD](https://procrd.pw)| ONLINE | |
|[PROJECT SPHERE](http://psphere7gzibrekpbvzitrul46aol2ibvnexpfymcne3xx4uzwdwdaad.onion/)| OFFLINE | |
|[PROLOGIC](https://prologic.su)| ONLINE | |
|[PROTON](https://proton.sc)| ONLINE | |
|[PSHACK](https://pshack.org)| ONLINE | |
|[RAID FORUMS 2](https://raidforums2.com)| OFFLINE | |
|[RAID FORUMS](https://raidforums.com)| OFFLINE | |
|[RAID FORUMS (Mirror 1)](https://rf.ws)| OFFLINE | |
|[RAID FORUMS (Mirror 2)](https://raid.lol)| OFFLINE | |
|[RAID FORUMS (Mirror 3)](https://rfmirror.com)| OFFLINE | |
|[RAID FORUMS TWO](https://raidforumstwo.com)| OFFLINE | |
|[RAMBLE](http://rambleeeqrhty6s5jgefdfdtc6tfgg4jj6svr4jpgk4wjtg3qshwbaad.onion)| ONLINE | |
|[RAMP (Dark)](http://rampjcdlqvgkoz5oywutpo6ggl7g6tvddysustfl6qzhr5osr24xxqqd.onion) | ONLINE | |
|[RAMP (Deep)](https://ramp4u.io) | ONLINE | |
|[RAMP (Old)](http://ramp4u5iz4xx75vmt6nk5xfrs5mrmtokzszqxhhkjqlk7pbwykaz7zid.onion) | OFFLINE | |
|[RAMP (Old)](http://wavbeudogz6byhnardd2lkp2jafims3j7tj6k6qnywchn2csngvtffqd.onion) | OFFLINE | |
|[RANSOMED](http://g6ocfx3bb3pvdfawbgrbt3fqoht5t6dwc3hfmmueo76hz46qepidnxid.onion) | ONLINE | |
|[REBREACHED](https://rebreached.vc) | ONLINE | |
|[REVERSING](https://reversing.center) | ONLINE | |
|[RF-CHEAT](https://www.rf-cheats.ru) | ONLINE | |
|[ROOTSPLOIT](https://rootsploit.org)| ONLINE | |
|[RUTOR (Dark)](http://rutordeepkpafpudl22pbbhzm4llbgncunvgcc66kax55sc4mp4kxcid.onion)| OFFLINE | |
|[RUTOR (Dark)](http://rutorbesth5lhmj47qz4fi5i4x5zvh4fizruog6iw2l3q223jmnawvid.onion)| ONLINE | |
|[RUTOR (Dark)](http://rutorclubwiypaf63caqzlqwtcxqu5w6req6h7bjnvdlm4m7tddiwoyd.onion)| ONLINE | |
|[RUTOR (Dark)](http://rutordark63xripv2a3skfrgjonvr3rqawcdpj2zcbw3sigkn6l3xpad.onion)| ONLINE | |
|[RUTOR (Deep)](https://darknet.rutor.nl) | ONLINE | |
|[RUTOR (Surface)](http://rutor.ac) | OFFLINE ||
|[RUTOR (Surface)](http://rutor.fr) | OFFLINE ||
|[RUTOR (Surface)](http://rutor.gs) | OFFLINE ||
|[RUTOR (Surface - torrent)](http://rutor.info) | ONLINE ||
|[RUTOR (Surface - torrent)](http://rutor.is) | ONLINE ||
|[RUTOR (Surface)](http://rutor.la) | OFFLINE ||
|[RUTOR (Surface)](http://rutor.li) | OFFLINE ||
|[RUTOR (Surface)](http://rutor.live) | OFFLINE ||
|[SECRET FORUM PROPAGANDA](http://qvwje7edtrfby6pfnm3q7o3lju22mfx3xsjyl3y33l66sbq3qcnlmvad.onion) | ONLINE | |
|[SEOPIRAT](https://seopirat.club) | ONLINE ||
|[SINFUL](https://sinfulsite.com)| ONLINE | |
|[SINISTER](https://sinister.ly)| ONLINE | |
|[SKYFRAUD](http://bcbm4y7yusdxthg3.onion)| OFFLINE | |
|[SKYNETZONE.BIZ](https://skynetzone.biz)| ONLINE | |
|[SKYNETZONE.PW](https://skynetzone.pw)| ONLINE | |
|[SOFTXAKER](http://forum.softxaker.ru)| ONLINE | |
|[SPYHACKERZ](https://spyhackerz.org)| ONLINE | |
|[SQLI](https://sqli.cloud)| ONLINE | |
|[STRESSED FORUM](https://stressedforums.pw)| ONLINE | |
|[SUPERBAY](http://suprbaydvdcaynfo4dgdzgxb4zuso7rftlil5yg5kqjefnw4wq4ulcad.onion)| ONLINE | |
|[THE GOOD LIFE](https://thegoodlife.to)| ONLINE | |
|[THE HUB](http://thehubwav7canwaq7trm6zl3tqvkf2kwbkgwvwonfssvgvtyrdy4u3yd.onion)| ONLINE | |
|[THE JAVA SEA](https://thejavasea.com)| ONLINE | |
|[TOOLBASE](https://toolba.se)| ONLINE | |
|[TRAFA NET](https://trafa.net)| ONLINE | |
|[TURKHACKTEAM](https://www.turkhackteam.org) | ONLINE | |
|[VAVILON](https://vavilon.cc)| ONLINE | |
|[VEDENET](https://vedenet.online) | ONLINE | |
|[VERIFIED (Dark)](http://verified3vr2kdbnza6c3e5ak4z5xmtti4hx36dfg3kbi6pwekztvsqd.onion/index.php)| ONLINE | |
|[VERIFIED (Deep)](https://ver.sc/index.php)| OFFLINE | |
|[VERYLEAKS](https://veryleaks.cz)| ONLINE | |
|[V-H.GURU](https://v-h.guru)| ONLINE | |
|[VLMI](https://vlmi.ws)| ONLINE | |
|[VSEMMONEY](https://vsemmoney.com)| ONLINE | |
|[WWHCLUB](https://wwh-club.io)| ONLINE | |
|[XREACTOR](https://xreactor.org)| ONLINE | |
|[XSS (Dark)](http://xssforumv3isucukbxhdhwz67hoa5e2voakcfkuieq4ch257vsburuid.onion)| ONLINE | |
|[XSS (Deep)](https://xss.is)| ONLINE | |
|[YOUHACK](https://youhack.xyz)| ONLINE | |
|[ZDL](https://zdl.pw)| ONLINE | |
